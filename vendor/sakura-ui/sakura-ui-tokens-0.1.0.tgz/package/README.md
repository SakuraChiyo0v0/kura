# @sakura-ui/tokens

框架无关的 CSS 变量（地基）。应用引入 `@sakura-ui/tokens/tokens.css`，在主题容器使用 `data-sk-theme="light|dark"`，需要换色板时再加 `data-sk-palette="<id>"`。

## 这个文件是生成的

`tokens.css` 和 `foundation.json` **都不是手写文件**，由 `scripts/build-tokens-css.mjs` 从三个源合成：

| 源 | 提供 |
| --- | --- |
| `packages/ui/src/theme.ts` 的 `themePresets` | 4 套色板（月白 / 海盐 / 落日 / 墨玉）× 亮暗的 12 个语义色 |
| `packages/ui/src/motion.ts` 的 `motionTiming` | 动效时长与缓动（CSS 过渡和 Motion 弹簧共用） |
| `packages/tokens/foundation.mjs` | 圆角、字体 |

```bash
npm run tokens:generate   # 重新生成 tokens.css 与 foundation.json
npm run tokens:check      # CI 校验是否已同步（已接入 npm run check）
```

改色板改 `theme.ts`，改节奏改 `motion.ts`，改圆角/字体改 `foundation.mjs`，**不要直接编辑 `tokens.css` 或 `foundation.json`**——下次生成会被覆盖。这样静态 CSS、运行时 `themeToStyle()` 与 Motion 动画读的是同一份数据，不会再各写一份而漂移。

## 变量分四层

1. **原始角色**（12 个）：`--sk-bg / surface / surface-raised / ink / muted / line / accent / accent-2 / accent-3 / success / warning / danger`
2. **派生角色**（按用途取用，组件和应用都不要现场再用 `color-mix()` 造一层）：`--sk-<role>-soft`（淡底）、`--sk-<role>-text`（对比度校正后的文字色）、`--sk-on-<role>`（该色上的前景色），由原始角色用 `color-mix()` 算出，全主题共用
   - 表面层级，由低到高：`--sk-surface-sunken`（嵌在表面里的凹槽：开关/滑轨轨道、分段底、详情块、悬停底）< `--sk-bg` < `--sk-surface` < `--sk-surface-raised`；`--sk-surface-overlay` 专给浮层（菜单、对话框、抽屉、通知、提示）。亮色下 overlay 取 surface（最白），暗色下取 raised（更亮才显得浮起）。组件只引用层级名，不再写 `var(a, var(b, var(c)))` 兜底链
   - `--sk-<role>-solid` / `--sk-on-<role>-solid`：填充色（主按钮、开关、勾选框、选中日期等铺底）。亮暗同值，取亮色版角色色、必要时加深到白字 4.5:1，前景恒为白。`--sk-<role>` 本身留给文字与描边——暗色下它会变浅，不适合铺大块底色
3. **形态**：`--sk-radius` `--sk-radius-control` `--sk-font`
4. **节奏**（只有一套）：`--sk-fast` 用于颜色、悬停、按压等即时反馈；`--sk-settle` 用于位移、展开、弹层等空间变化；`--sk-ease` 是共用缓动。组件里的 Motion 弹簧用 `visualDuration` 对齐到 `--sk-settle`，所以 CSS 过渡和弹簧的手感一致

节奏只有这一套，所有产品共用、不提供加速档。`data-sk-motion="off"` 或系统 `prefers-reduced-motion: reduce` 时归零。

滚动条也属于地基：引入 tokens.css 后全局生效，细、无箭头、轨道透明，滑块随主题取 `--sk-scrollbar-thumb`（悬停 `--sk-scrollbar-thumb-hover`）。组件和应用不要再各写一套 `::-webkit-scrollbar`。Chromium / Electron 走 `::-webkit-*`；标准的 `scrollbar-width / scrollbar-color` 只给不支持它的浏览器，否则 Chromium 会忽略 `::-webkit-*`，在 Windows 上带回箭头。

原生页面、Vue、任意 CSS 方案都能直接用这些变量；这不代表 React 组件可直接在 Vue 使用。

## 给其他项目用：foundation.json

`foundation.json` 是同一份变量清单的前缀无关版本：`shape`（圆角、字体）、`motion`（唯一一套时长与缓动）、`palettes.<id>.light|dark`（每种模式的角色、前景、填充、浮层、阴影色）、`derived`（全主题共用的派生层）。变量名不带前缀，值里的相互引用写作 `var(--sk-*)`。

不直接依赖 Sakura UI 的项目（例如 Electron 组件库 TS-Library）把它作为快照提交进自己的仓库，在构建期把 `--sk-` 换成自己的前缀生成 CSS，并在构建里校验生成物与快照一致。这样两边读的是同一份地基，又不引入运行时依赖。地基更新后，消费方重新拷贝快照、重新生成即可；不要在消费方手改生成出来的色值。
