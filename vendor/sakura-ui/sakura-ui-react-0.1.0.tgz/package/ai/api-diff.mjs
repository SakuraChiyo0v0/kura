import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const order=(a,b)=>a.id<b.id?-1:a.id>b.id?1:0;
export function surfaceFingerprint(snapshot) {
  const deps=Object.fromEntries(Object.entries(snapshot.dependencies).sort(([a],[b])=>a.localeCompare(b,'en')));
  const peers=Object.fromEntries(Object.entries(snapshot.peerDependencies).sort(([a],[b])=>a.localeCompare(b,'en')));
  const entries=[...snapshot.entries].sort(order).map(item=>({id:item.id,category:item.category,name:item.name,kind:item.kind,tokens:item.tokens,props:item.props?.map(prop=>({name:prop.name,required:prop.required,tokens:prop.tokens})).sort((a,b)=>a.name.localeCompare(b.name,'en'))}));
  return createHash('sha256').update(JSON.stringify({normalizerVersion:snapshot.normalizerVersion,dependencies:deps,peerDependencies:peers,entries})).digest('hex');
}
function validate(snapshot) {
  if(!snapshot || snapshot.schemaVersion!==1 || snapshot.normalizerVersion!==1 || snapshot.package!=='@sakura-ui/react' || typeof snapshot.version!=='string' || !Array.isArray(snapshot.entries))throw new Error('不支持的接口快照');
  for(const key of ['dependencies','peerDependencies']) if(!snapshot[key] || typeof snapshot[key]!=='object' || Array.isArray(snapshot[key]) || Object.values(snapshot[key]).some(value=>typeof value!=='string'))throw new Error('快照依赖声明无效');
  const ids=new Set(),namespaces=new Set();const tokens=value=>Array.isArray(value)&&value.every(token=>typeof token==='string');
  for(const item of snapshot.entries) {
    if(!item || typeof item.name!=='string' || !item.name || typeof item.kind!=='string' || typeof item.definition!=='string' || !['components','types','apis'].includes(item.category) || item.id!==item.category+':'+item.name || ids.has(item.id) || !tokens(item.tokens))throw new Error('接口条目无效或重复');
    ids.add(item.id);
    const namespace=(item.category==='types'?'type:':'value:')+item.name;
    if(namespaces.has(namespace))throw new Error('公共名称在同一命名空间重复');namespaces.add(namespace);
    if(item.category==='components') {
      if(!Array.isArray(item.props))throw new Error('组件属性快照缺失');
      const names=new Set();for(const prop of item.props) {
        if(!prop || typeof prop.name!=='string' || names.has(prop.name) || typeof prop.required!=='boolean' || typeof prop.type!=='string' || !tokens(prop.tokens))throw new Error('属性快照无效');
        names.add(prop.name);
      }
    }
  }
  if(surfaceFingerprint(snapshot)!==snapshot.surfaceHash)throw new Error('接口快照摘要不匹配');
}
export function compareSnapshots(before,after) {
  validate(before);validate(after);
  const changes=[];const previous=new Map(before.entries.map(item=>[item.id,item]));const current=new Map(after.entries.map(item=>[item.id,item]));
  const sameNamespace=(a,b)=>a.name===b.name && (a.category==='types')===(b.category==='types');
  const add=(level,kind,name,detail)=>changes.push({level,kind,name,detail});
  for(const [id,item] of previous) {
    const next=current.get(id);
    if(!next){
      const reclassified=after.entries.find(candidate=>sameNamespace(item,candidate));
      if(reclassified)add('review','category-changed',item.name,{before:item.category,after:reclassified.category,beforeDefinition:item.definition,afterDefinition:reclassified.definition});
      else add('breaking-risk','export-removed',item.name,{category:item.category});
      continue;
    }
    if(item.kind!==next.kind)add('review','kind-changed',item.name,{before:item.kind,after:next.kind});
    if(item.category==='components') {
      if(JSON.stringify(item.tokens)!==JSON.stringify(next.tokens))add('review','component-signature-changed',item.name,{before:item.definition,after:next.definition});
      const oldProps=new Map(item.props.map(prop=>[prop.name,prop]));const nextProps=new Map(next.props.map(prop=>[prop.name,prop]));
      for(const [name,prop] of oldProps) {
        const updated=nextProps.get(name);
        if(!updated){add('review','property-removed',item.name,{property:name,note:'检查是否仍从原生属性继承，以及实际调用点。'});continue;}
        if(!prop.required && updated.required)add('breaking-risk','property-now-required',item.name,{property:name});
        else if(prop.required && !updated.required)add('review','property-now-optional',item.name,{property:name});
        if(JSON.stringify(prop.tokens)!==JSON.stringify(updated.tokens))add('review','property-type-changed',item.name,{property:name,before:prop.type,after:updated.type});
      }
      for(const [name,prop] of nextProps)if(!oldProps.has(name))add(prop.required?'breaking-risk':'addition','property-added',item.name,{property:name,required:prop.required,type:prop.type});
    } else if(JSON.stringify(item.tokens)!==JSON.stringify(next.tokens))add('review','declaration-changed',item.name,{category:item.category,before:item.definition,after:next.definition});
  }
  for(const [id,item] of current)if(!previous.has(id) && !before.entries.some(candidate=>sameNamespace(item,candidate)))add('addition','export-added',item.name,{category:item.category});
  for(const group of ['dependencies','peerDependencies']) {
    for(const name of new Set([...Object.keys(before[group]),...Object.keys(after[group])]))if(before[group][name]!==after[group][name])add('review','dependency-declaration-changed',name,{group,before:before[group][name]??null,after:after[group][name]??null});
  }
  return {schemaVersion:1,status:changes.length?'review-required':'unchanged',package:after.package,beforeVersion:before.version,afterVersion:after.version,beforeHash:before.surfaceHash,afterHash:after.surfaceHash,compatibility:'not-proven',changes,notCompared:['运行时实现和视觉效果','继承的外部类型定义与完整传递依赖','真实消费项目是否仍通过编译与交互'],note:'这是声明差异报告，不执行类型可赋值证明，不自动选择版本或升级项目。'};
}
if(import.meta.url.startsWith('file:') && process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try {
    const args=process.argv.slice(2);let before,after,check=false;
    for(let i=0;i<args.length;i++) {
      if(args[i]==='--check')check=true;
      else if(args[i]==='--before' && args[i+1])before=args[++i];
      else if(args[i]==='--after' && args[i+1])after=args[++i];
      else throw new Error('用法：node api-diff.mjs --before 旧快照 --after 新快照 [--check]');
    }
    if(!before || !after)throw new Error('必须明确指定前后两份快照，不推断升级方向');
    const result=compareSnapshots(JSON.parse(readFileSync(before,'utf8')),JSON.parse(readFileSync(after,'utf8')));
    console.log(JSON.stringify(result,null,2));if(check && result.changes.length)process.exitCode=1;
  } catch(error){console.error(error.message);process.exitCode=2;}
}
