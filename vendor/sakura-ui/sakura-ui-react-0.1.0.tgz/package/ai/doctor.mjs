import { readFileSync, existsSync, realpathSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const packageNames=['react','react-dom','@sakura-ui/react','@sakura-ui/tokens'];
const readJson=path=>JSON.parse(readFileSync(path,'utf8'));
const declarationSections=['dependencies','devDependencies','peerDependencies','optionalDependencies'];
const supportedReact=version=>/^19\.\d+\.\d+$/.test(version);

export function diagnoseProject(projectDirectory) {
  const project=resolve(projectDirectory);
  const checks=[];const packages=[];
  const add=(code,severity,message)=>checks.push({code,severity,message});
  const finish=()=>({schemaVersion:1,project,status:checks.some(check=>check.severity==='error')?'needs-attention':'dependencies-ready',packages,checks,notVerified:['应用 Provider 和 CSS 是否实际加载','全部传递依赖的完整性与运行时加载','消费项目类型检查与构建','运行交互与业务回执','浏览器布局与用户审美','SSR 和其他框架兼容']});
  let manifest;
  try { manifest=readJson(join(project,'package.json'));if(!manifest || typeof manifest!=='object' || Array.isArray(manifest)) throw new Error('清单必须是对象'); }
  catch(error) { add('project-manifest','error','无法读取项目 package.json：'+error.message);return finish(); }
  for(const section of declarationSections) if(manifest[section]!==undefined && (!manifest[section] || typeof manifest[section]!=='object' || Array.isArray(manifest[section]))) {
    add('dependency-declarations','error',section+' 必须是依赖名与版本声明的对象');return finish();
  }
  // Resolution is anchored to the consumer, never to this script's own package.
  // require.resolve reads paths; it does not execute the project's modules.
  const requireFromProject=createRequire(join(project,'package.json'));
  function findManifest(name) {
    const entries=name==='@sakura-ui/react'
      ? [['@sakura-ui/react/ai/catalog.json',1],['@sakura-ui/react/styles.css',1]]
      : name==='@sakura-ui/tokens' ? [['@sakura-ui/tokens/tokens.css',0]] : [[name+'/package.json',0]];
    for(const [entry,parents] of entries) {
      try {
        const path=requireFromProject.resolve(entry);
        let dir=dirname(path);for(let i=0;i<parents;i++) dir=dirname(dir);
        const file=join(dir,'package.json');const data=readJson(file);
        if(data.name===name && typeof data.version==='string') return {manifest:data,path:realpathSync(file),directory:dir};
      } catch { /* Try another public export without importing implementation. */ }
    }
    return null;
  }
  const installed=new Map();
  for(const name of packageNames) {
    const declarations=declarationSections.filter(section=>Object.hasOwn(manifest[section]||{},name)).map(section=>({section,value:manifest[section][name]}));
    const found=findManifest(name);installed.set(name,found);
    packages.push({name,declarations,installedVersion:found?.manifest.version??null,resolvedManifest:found?.path??null});
    if(!declarations.length) add('undeclared:'+name,'error',name+' 未在此项目声明；即使祖先目录可解析，也不视为已接入。请按项目依赖策略显式声明。');
    else if(declarations.some(item=>typeof item.value!=='string' || !item.value.trim())) add('invalid-declaration:'+name,'error',name+' 的版本声明无效。');
    if(!found) add('not-installed:'+name,'error','无法从目标项目解析 '+name+'；请先检查安装或工作区依赖，诊断不会自动安装。');
    if(found && (name==='react' || name==='react-dom')) {
      if(!supportedReact(found.manifest.version)) add('unsupported:'+name,'error',name+' 实际版本为 '+found.manifest.version+'，当前仅验证稳定版 React 19。请评估迁移或使用兼容的组件库版本。');
      for(const declaration of declarations) {
        const simple=/^[~^]?(\d+)(?:\.|$)/.exec(String(declaration.value));
        if(simple && Number(simple[1])!==Number(found.manifest.version.split('.')[0])) add('declaration-mismatch:'+name,'error',name+' 声明与实际安装的主版本不同，请核对安装结果或锁文件。');
      }
    }
  }
  const react=installed.get('react'),dom=installed.get('react-dom'),ui=installed.get('@sakura-ui/react'),tokens=installed.get('@sakura-ui/tokens');
  if(react && dom && react.manifest.version!==dom.manifest.version) add('react-pair','error','React 与 React DOM 的实际版本不同，应使用匹配版本。');
  if(ui && tokens && ui.manifest.version!==tokens.manifest.version) add('sakura-pair','error','Sakura 组件与主题包版本不同，请使用同一份交付中的两个包。');
  if(ui) {
    try {
      const catalog=readJson(join(ui.directory,'ai/catalog.json'));
      if(catalog.schemaVersion!==1 || catalog.package!=='@sakura-ui/react' || catalog.version!==ui.manifest.version) throw new Error('目录与安装包版本不一致');
      if(!Array.isArray(catalog.components) || !catalog.components.length || !Array.isArray(catalog.recipes) || !catalog.recipes.length) throw new Error('目录缺少组件或组合范例');
      for(const file of ['ai/START_HERE.md','ai/query.mjs','ai/design-rules.md','dist/index.d.ts']) if(!existsSync(join(ui.directory,file))) throw new Error('缺少 '+file);
      const declaredHere=packages.find(item=>item.name==='@sakura-ui/react')?.declarations.length;
      add('ai-materials','info',declaredHere?'可读取与解析版本一致的 AI 材料；接入状态仍以全部检查为准。':'解析到了 AI 材料，但本项目未声明组件包，尚未完成接入。');
    } catch(error) { add('ai-materials','error','AI 材料不可用：'+error.message); }
    try {
      const current=readJson(new URL('./catalog.json',import.meta.url));
      if(current.version!==ui.manifest.version) add('doctor-version','warning','当前诊断材料与已安装组件版本不同；接入时优先阅读已安装版本的 AI 说明。');
    } catch { add('doctor-version','warning','无法读取诊断器随附目录，已按实际安装包检查。'); }
  }
  for(const entry of ['@sakura-ui/react/styles.css','@sakura-ui/tokens/tokens.css']) {
    try { requireFromProject.resolve(entry); }
    catch { add('style-export:'+entry,'error','无法解析样式入口 '+entry+'。'); }
  }
  if(['next','nuxt','vue','@remix-run/react'].some(name=>declarationSections.some(section=>Object.hasOwn(manifest[section]||{},name)))) add('framework','warning','检测到额外框架依赖；本诊断仅覆盖 React 客户端依赖，SSR/其他框架需要单独验证。');
  add('range-scope','info','报告实际解析版本；不会完整解释 npm 别名、复杂 semver、workspace/catalog 声明或校验整个锁文件。');
  return finish();
}

if(import.meta.url.startsWith('file:') && process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const args=process.argv.slice(2);
  if(args.length && (args.length!==2 || args[0]!=='--project')) {
    console.error('用法：node doctor.mjs [--project <项目目录>]');process.exitCode=2;
  } else {
    const result=diagnoseProject(args[1] || process.cwd());console.log(JSON.stringify(result,null,2));
    if(result.status!=='dependencies-ready') process.exitCode=1;
  }
}
