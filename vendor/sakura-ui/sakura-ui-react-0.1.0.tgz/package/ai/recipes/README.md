# 可复制的组合范例

将需要的 TSX 与 `recipes.css` 复制到应用中；这些文件是应用代码模板，不是新的包导出。只从 `@sakura-ui/react` 公共入口导入组件。宿主需使用 React 19，在应用入口导入 `@sakura-ui/tokens/tokens.css` 和 `@sakura-ui/react/styles.css`。三份范例均不依赖 Studio、不默认请求网络，也不需要 `ToastProvider`。

## 应用框架：AppShellRecipe

已包含 `SakuraProvider`；把业务页面放在 `children`。主题和路由由宿主控制，默认动效为 `soft`，系统减少动效偏好由组件库处理。若应用已有 Provider，可把内部布局取出复用，避免两套主题状态。

```tsx
import { useState } from 'react';
import { themePresets, type SakuraTheme } from '@sakura-ui/react';
import '@sakura-ui/tokens/tokens.css';
import '@sakura-ui/react/styles.css';
import { AppShellRecipe } from './recipes/app-shell';

export function App() {
  const [route, setRoute] = useState('resources');
  const [theme, setTheme] = useState<SakuraTheme>('light');
  const [palette, setPalette] = useState(themePresets[0]);
  return <AppShellRecipe title="我的空间" pageTitle={route === 'resources' ? '资源管理' : '设置'}
    items={[{ id: 'resources', label: '资源', icon: <span aria-hidden="true">▤</span> },
      { id: 'settings', label: '设置', icon: <span aria-hidden="true">⚙</span> }]}
    activeId={route} onNavigate={setRoute} theme={theme} onThemeChange={setTheme}
    palette={palette} onPaletteChange={setPalette}>
    {route === 'resources' ? <p>在这里放 ResourceManagerRecipe。</p> : <p>设置内容。</p>}
  </AppShellRecipe>;
}
```

此最小例用本地状态演示导航。实际项目把 `activeId/onNavigate` 接到自己的路由器，并为导航项提供真实 `href`。主题偏好持久化、页面权限和异步路由加载属于宿主。全局下载控制器应放在 `PageTransition` 之外，因为路由切换会卸载旧页面。

## 资源管理：ResourceManagerRecipe

输入 `resources: RecipeResource[]`、受控 `selectedIds` 和 `onSelectionChange`。`onBatchAction` 得到调用瞬间选中的有效 ID 快照。Promise 成功代表宿主约定的操作已完成；若只是提交远端任务，应修改范例反馈文案为“已提交”，不要宣称处理完成。发生错误时抛出异常，范例保留选择并显示错误。

```tsx
<ResourceManagerRecipe resources={resources} selectedIds={selectedIds}
  onSelectionChange={setSelectedIds} batchActionLabel="加入整理任务"
  onBatchAction={async ids => { await processResources(ids); await refreshResources(); }}
  createAction={<Button onClick={openCreateDialog}>添加资源</Button>} />
```

这里的 `resources`、选择状态和三个业务函数由应用实现，不是库内置服务。默认详情通过抽屉查看；传 `renderDetails(resource)` 可替换内容。新增入口始终显示在标题旁。只对中小规模、全部已载入的数据进行客户端搜索、排序与分页；大数据应由应用提供服务端列表适配，不要把当前页冒充总数据。

## 下载流程：DownloadFlowRecipe

需要祖先 `SakuraProvider`（可直接放在 `AppShellRecipe` 中）。输入 `resource`、允许展示的 `targets`、真实 `execute`。目标仅展示所传的配置，不要求同时包含本机、服务端和 WebDAV。

```tsx
// 页面级控制器：关闭下载浮窗后仍保留任务。若需跨路由存活，把此 hook 放到持久布局。
const controller = useDownloadTask(executeDownload);
<DownloadFlowRecipe resource={{ id: 'asset-1', label: '资料包', fileName: 'assets.zip' }}
  targets={[{ id: 'browser', kind: 'browser', label: '本机下载' }]}
  execute={executeDownload} controller={controller} />
```

传入 `controller` 时，其创建时使用的执行器才负责运行任务，请保证它与 `execute` 一致。未传则范例自己创建控制器，其寿命为范例组件的挂载期。它不能保证刷新页面后恢复，也不是远端任务队列。

执行器遵循 `DownloadExecutor`：接收冻结的请求、`signal` 与 `onProgress`。本机可用公开的 `createBrowserDownloadExecutor`；远端调用由宿主实现鉴权、目标授权、根目录限制、幂等和取消确认。不要在浏览器保存 WebDAV 密钥。

- `completed`：目标确认文件保存完成。
- `submitted`：只确认接单，未确认写盘。
- `handed-off`：交给浏览器，不能确认浏览器最终保存。
- `cancelled`：目标明确确认已取消；`AbortSignal` 本身不代表远端停止。
- `interrupted`：仅停止等待，保存状态未知。

需要离线演示时显式传入模拟执行器，结果必须携带 `simulated: true`：

```tsx
import type { DownloadExecutor } from '@sakura-ui/react';
const simulateDownload: DownloadExecutor = async (_request, { signal, onProgress }) => {
  if (signal.aborted) return { kind: 'cancelled', simulated: true };
  onProgress({ phase: 'saving', message: '仅演示反馈，不写入文件。' });
  return { kind: 'completed', simulated: true, message: '演示完成，没有保存文件。' };
};
```

验收时检查：浅色/深色与自定义配色、窄屏导航、键盘焦点、无匹配数据、批量失败反馈、下载浮窗关闭重开，以及真实执行和模拟结果的区别。这些范例允许修改布局和业务适配，底层组件继续从包中复用。

## 收藏工作室的呈现方式

`AppShellRecipe compactChrome` 将主题选择收进“外观设置”浮窗，侧栏初始仅显示图标，仍可展开。主题和路由仍由宿主控制。

`ResourceManagerRecipe` 有三种视图，共享搜索和受控选择，用户可以随时切换：

| 视图 | 适合 | 布局 |
| --- | --- | --- |
| `shelf` 陈列 | 浏览收藏、素材 | 第一项放大陈列并配说明，其余按每行 3 件（窄屏 2 件）排在展架上 |
| `index` 目录 | 按名称查找、标题较长 | 大字号编号条目；悬停或聚焦的条目在右侧显示封面，窄屏隐藏预览 |
| `list` 列表 | 逐行比较、排序 | 可排序表格，默认视图 |

`initialView` 选初始视图，`views` 决定切换里提供哪些（如 `['shelf','list']`），只给一种时不显示切换。`initialView="gallery"` 是 `shelf` 的旧名，继续可用。两种收藏视图任意数量都按同一规则排布，不依赖固定条目数；陈列只有一件时不出现空展架。每次显示 8 项，通过“显示更多收藏”继续加载已在内存中的数据。陈列的首件就是排序后的第一项，若要“当期精选”，由宿主先排好序。

`title`、`description` 控制页内介绍，不影响导航标题。创建入口始终可见。

每条 `RecipeResource.cover` 可选 `notes | landscape | ribbon | archive`。这是随主题变化的装饰性封面，不是真实文件缩略图；它不向辅助技术重复朗读。自定义封面使用相同的尺寸容器，图片按 `object-fit: cover` 裁切；需要完整呈现时可在业务图片上设置 `objectFit: contain`。传 `renderCover(resource)` 可使用业务图片等内容，避免嵌套按钮或链接，因为封面本身已是详情触发器。保留 `recipes.css`，纸页展开、选中和窄屏样式才能一起复制；系统减少动态效果或关闭动效时不执行封面变形。

```tsx
<ResourceManagerRecipe initialView="shelf" views={['shelf', 'index', 'list']}
  title="我的收藏" description="保存值得回看的素材。"
  resources={resources} selectedIds={selectedIds} onSelectionChange={setSelectedIds}
  onBatchAction={processResources} createAction={<Button onClick={openCreateDialog}>添加资源</Button>} />
```

预览中的“收藏室”是一个可替换的产品方向，不应套用到所有数据密集型应用。记录、日志、订单等需要逐行比较的内容优先使用列表；封面用于确实适合浏览的资源。
