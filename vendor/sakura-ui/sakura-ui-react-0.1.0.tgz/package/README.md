# @sakura-ui/react

React 19 组件库，当前为 0.1.0 实验版。组件负责呈现、键盘与动效，业务数据、请求、路由和持久化由应用管理。当前用于本地演示与跨项目复用验证，API 仍可能调整，尚未发布到 npm 注册表。技术验证与用户视觉验收分开记录。

## 给 AI 的入口

先读 [AI 接入说明](ai/START_HERE.md)，再通过 [组件索引](ai/catalog.json) 或 `ai/query.mjs` 按需查询。三个可复制的组合范例位于 `ai/recipes`；配套 Skill 位于 `ai/skill`。材料随安装包分发，与 Studio 目录共用数据。

## 开始使用

应用需要安装 React 19、React DOM 19，以及本库和 `@sakura-ui/tokens`。样式只需导入一次。

```tsx
import { useState } from 'react';
import '@sakura-ui/tokens/tokens.css';
import '@sakura-ui/react/styles.css';
import {
  SakuraProvider, SelectField, SwitchField, Button, themePresets,
} from '@sakura-ui/react';

export function Preferences() {
  const [quality, setQuality] = useState('balanced');
  const [preview, setPreview] = useState(true);

  return (
    <SakuraProvider theme="light" motionPreset="soft" palette={themePresets[0]}>
      <SelectField
        label="预览质量"
        value={quality}
        onValueChange={setQuality}
        options={[
          { value: 'light', label: '轻量' },
          { value: 'balanced', label: '平衡', description: '兼顾细节与加载速度' },
          { value: 'original', label: '原始', disabled: true },
        ]}
      />
      <SwitchField label="显示预览" checked={preview} onCheckedChange={setPreview} />
      <Button variant="secondary" onClick={() => setQuality('balanced')}>恢复默认</Button>
    </SakuraProvider>
  );
}
```

## 主题与动效

`SakuraProvider` 必填 `theme: 'light' | 'dark'`、`motionPreset: 'soft' | 'off'`（开启 / 关闭，只有一套节奏） 和 `children`。可选 `palette: SakuraPalette`，默认“月白”。系统“减少动态效果”优先于应用动效选择，运行中改变系统偏好也会生效。

`SakuraPalette` 包含 `id`、`name` 和 `colors.light` / `colors.dark` 两组配色。每组 12 个角色：`background`、`surface`、`surfaceRaised`、`text`、`muted`、`border`、`accent`、`accent2`、`accent3`、`success`、`warning`、`danger`。各颜色使用 `#RRGGBB`；两种模式可以分别编辑。

```tsx
import { themePresets, parseTheme, serializeTheme } from '@sakura-ui/react';

const jsonText = serializeTheme(themePresets[0]);
// parseTheme 接收解析后的对象；输入错误时抛出带说明的 Error。
const importedPalette = parseTheme(JSON.parse(jsonText));
```

主题文件包含 `version: 1`，只接受约定字段与颜色数据，不载入 CSS、HTML 或脚本。读取文件、下载文件和本地保存由应用实现。

`themeToStyle(palette, mode)` 返回可传给 React `style` 的 CSS 变量，适合普通 HTML 或应用专属组件。它与 `@sakura-ui/tokens/tokens.css` 由同一份规则产出，变量清单和含义见 [tokens 说明](../tokens/README.md)。写应用专属样式时按用途选变量：

| 用途 | 变量 |
| --- | --- |
| 页面、卡片、浮起的块 | `--sk-bg` < `--sk-surface` < `--sk-surface-raised` |
| 嵌在表面里的凹槽（轨道、分段底、详情块、悬停底） | `--sk-surface-sunken` |
| 浮层（菜单、对话框、抽屉、通知） | `--sk-surface-overlay` |
| 实心填充（主按钮、开关、选中态）及其上的文字 | `--sk-accent-solid` + `--sk-on-accent-solid`（其余角色同理，如 `--sk-danger-solid`） |
| 强调文字、描边、图标 | `--sk-accent-text`、`--sk-accent` |
| 淡底（选中行、图标底衬） | `--sk-accent-soft` |
| 过渡时长 | `--sk-fast`（颜色、按压）、`--sk-settle`（位移、展开），缓动 `--sk-ease` |

`--sk-accent` 在暗色下会变浅以保证文字可读，不要直接拿它铺按钮底色；填充一律用 `-solid`，它在亮暗两种模式下是同一块色、配白字。时长只有这一套，所有产品共用；`motionPreset="off"` 归零，不提供加速档，也不另设刻度。`useSakuraMotion()` 返回当前 `theme`、`palette`、`themeStyle`、`effectiveMotion`、`animated`、`transition`、`feedbackTransition`。共享 Select、Popover 和 Dialog 会将当前主题与动效配置带到弹层中。

## 组件 API

当前包含 40 类逻辑组件：下表的 39 个可渲染控件，以及 Toast 通知。Provider、hook 和主题工具作为基础 API 单列，不重复计为组件。

| 组件 | 必填属性 | 可选属性与行为 |
|---|---|---|
| `Button` | 无；通常传入 `children` 或 `aria-label` | `variant: primary / secondary / ghost`，`size: sm / md / lg`，`icon`。支持原生 button 属性和 ref，默认 `type="button"`，包含按压反馈。仅图标按钮须给出可访问名称。 |
| `SelectField` | `label`、`options`、`value: string \| null`、`onValueChange(string)` | `placeholder`、`size: sm / md / lg`、`disabled`、`name`、`style`、`className`。选项类型 `SelectFieldOption` 包含 `value`、`label`，以及可选 `description`、`icon: ReactNode`、`disabled`。 |
| `SwitchField` | `label`、`checked`、`onCheckedChange(boolean)` | `description`、`disabled`、`name`、`style`、`className`。采用原生 checkbox 的状态与键盘行为，并提供 switch 语义。 |
| `FluidSegmented` | `label`、`options`、`value`、`onValueChange(string)` | 每项为 `{ value, label, icon? }`。原生 radio group，方向键移动，选中背景连续跟随。 |
| `ActionButton` | `children`、`onAction: () => Promise<void>` | `successLabel`、`errorLabel`。等待期间防止重复执行，成功与失败状态保留到下次点击；应用传入真正需要等待的 Promise。 |
| `MorphingSurface` | `title`、`subtitle`、`icon`、`children` | `variant: compact / spatial`，`defaultOpen`、`footer`、`preview`。收起后内容保持挂载但退出交互；`preview` 仅作装饰，真实操作放入 `children` 或 `footer`。 |
| `SidebarNav` | `items`、`activeId`、`onNavigate(id)`、`collapsed`、`onCollapsedChange(boolean)` | 每项为 `{ id, label, icon, href?, badge? }`；可传 `header`、`footer`、`label`、`className`、`style`。折叠仍保留可访问名称，链接支持修饰键打开；窄屏容器由应用处理。 |
| `PageTransition` | `routeKey`、`children` | `className`。key 改变时进行页面过渡，离场内容立即不可交互；不内置路由器，页面标题焦点和滚动位置由应用决定。 |
| `FloatingPanel` | `label`、`title`、`children` | `icon`、`className`、`open`、`onOpenChange(boolean)`。锚定触发入口的小浮层，`className` 应用在触发按钮。 |
| `FocusDialog` | `triggerLabel`、`title`、`description`、`children` | `open`、`onOpenChange(boolean)`、`triggerContent`、`triggerClassName`、`className`、`initialFocus`、`finalFocus`。`className` 应用在浮窗；焦点属性为 `RefObject<HTMLElement \| null>`。默认进入浮窗本体并在关闭时返回触发入口。 |
| `SearchSelect` | `label`、`options`、`values: string[]`、`onValuesChange(string[])` | `placeholder`、`emptyLabel`、`disabled`、`maxSelected`、`className`、`style`。选项为 `{ value, label, description?, icon?, disabled? }`；可搜索名称与说明，以标签显示多选值。 |
| `ActionMenu` | `label`、`items`、`onAction(id)` | `icon`、`className`。项为 `{ id, label, icon?, shortcut?, disabled?, tone?: normal / danger, separatorBefore? }`；有 `icon` 时入口为带可访问名称的图标按钮。`shortcut` 仅展示，快捷键监听由应用管理。 |
| `MotionTabs` | `label`、`items`、`value`、`onValueChange(string)` | `variant: line / pill`、`className`。项为 `{ value, label, icon?, disabled?, content }`；方向键切换，活动内容进入，离场内容立即卸载，仅保留动画外壳。 |
| `RangeField` | `label`、`value: number`、`onValueChange(number)` | `min=0`、`max=100`、`step=1`、`formatValue(number)`、`description`、`disabled`、`icon`、`className`。单值滑杆，支持鼠标、触摸和键盘；格式化值同时用于读屏。 |
| `DrawerPanel` | `triggerLabel`、`title`、`description`、`children` | `footer`、`open`、`onOpenChange(boolean)`、`side: right / left`、`triggerContent`、`triggerClassName`。从侧边进入的模态详情区，内容区独立滚动，支持 Esc 关闭和焦点返回。 |
| `Hint` | `content`、`children: ReactElement` | `side: top / right / bottom / left`、`delay=450`（毫秒）。单个可接收 ref 和事件的元素作为入口，支持悬停或键盘聚焦；文字仅作补充说明。 |
| `TextField` | `label` | 继承原生 input 属性和 ref；额外支持 `description`、`error`、`prefix`、`suffix`、`showCount`。`className` 用于外层，`style` 等原生属性传给 input；不改写输入、不内置业务校验。 |
| `CheckboxCards` | `label`、`options`、`values: string[]`、`onValuesChange(string[])` | `description`、`columns: 1 / 2`（默认 2，窄屏自动一列）、`allowSelectAll=false`、`className`。项为 `{ value, label, description?, icon?, disabled? }`，实际使用原生 checkbox。 |
| `DateField` | `label`、`value: string \| null`、`onValueChange(string \| null)` | `min`、`max`、`placeholder`、`disabled`、`description`、`error`、`className`。日期字符串为真实的 `YYYY-MM-DD`，`null` 表示清空；日期值不携带时间或时区。 |
| `StepFlow` | `label`、`steps`、`currentStep` | `completedSteps`、`onStepChange(id)`、`orientation: horizontal / vertical`。步骤为 `{ id, title, description?, icon? }`；只有当前或明确标记为已完成的步骤可成为回访入口，不自动跳过未完成步骤。 |
| `ProgressBar` | `label` | `value`、`max=100`、`description`、`tone: accent / success / warning / danger`、`showValue=true`、`paused=false`。省略 `value` 表示进度未知，`paused` 可暂停未知进度的动效，不以假百分比替代。 |
| `EmptyState` | `title` | `description`、`icon`、`action`、`secondaryAction`。操作内容由应用传入，组件不猜测业务流程。 |
| `Skeleton` | 无 | `width`、`height`、`shape: line / circle / rect`、`animated=true`、`className`。仅为视觉占位，`aria-hidden`；外层负责 `aria-busy` 与加载说明。 |
| `DownloadPanel` | `resource`、`targets`、`execute` | `initialTargetId`、`controller`、`onStateChange`、`className`。任务可由内部管理，也可通过外部 `useDownloadTask` 在关闭浮窗后保留。 |
| `DownloadForm` | `resource`、`targets`、`value: DownloadDraft`、`onValueChange` | `onSubmit`、`disabled`、`readOnly`、`submitLabel`、`hideSubmit`、`className`。纯受控配置表单；收到新值只更新显示，编辑与校验通过后的提交才报告用户意图。 |
| `ActivitySwitcher` | `activities`、`value: string \| null`、`onValueChange(id)` | `label`、`className`。活动项为 `{id,label,description?,actorLabel?,phase?}`；外部活动更新不自动改选观察对象。 |
| `FollowControls` | `mode: follow / browse`、`onModeChange` | `connection: connected / reconnecting / disconnected`、`takeover: idle / pending / confirmed / rejected`、`onTakeover`、`takeoverMessage`、`className`。观看与接管分开，确认结果由应用传入。 |
| `ActivitySurface` | `regionId`、`title`、`expanded`、`onExpandedChange`、`children` | `description`、`highlighted`、`ref`、`className`。内容保持挂载；收起时不可交互。与跟随 hook 通过稳定区域 ID 组合。 |
| `SharedDraftPanel` | `revision`、`children` | `title`、`dirty`、`pending`、`conflictRevision`、`error`、`disabled`、`onSave`、`onAcceptLatest`、`onRebase`、`footer`，以及原生 section 属性。只展示草稿状态与显式操作；字段和保存由应用提供。 |
| `TaskCollection` | `tasks` | `onAction(taskId,actionId)`、`renderDetails(task)`、`renderResult(task)`、`emptyLabel`、`className`。任务类型见下文；动作能力由调用方明确给出，不按阶段推断取消或重试权限。 |
| `OperationTimeline` | `entries` | `onLocate(entry)`、`emptyLabel`、`className`。记录为 `{id,title,at?,actor?,description?,surfaceId?}`，保留传入顺序。定位只改变观看，不能重发记录中的业务命令。 |

本轮新增的数据组件：

| 组件 | 必填属性 | 可选属性与行为 |
| --- | --- | --- |
| `DataTable<T>` | `label`、`rows`、`columns`、`getRowId` | `getRowLabel`、`searchText`、`searchPlaceholder`、`query/onQueryChange`、`sort/onSortChange`、`defaultSort`、`page/onPageChange`、`pageSize`、`selectedIds/onSelectionChange`、`isRowSelectable`、`rowActions`、`toolbar`、`loading`、`emptyLabel/emptyDescription`、`className`。本地搜索/排序/分页，原生表格语义。 |
| `FileDropzone` | `label`、`files`、`onFilesChange` | `accept`、`maxFiles=5`、`maxSizeBytes=10485760`、`onRejected`、`description`、`disabled`、`className`。受控文件选择，不读取内容或自动上传；可选择或拖入文件。 |
| `StatusBadge` | `children` | `tone: neutral/accent/success/warning/danger`、`variant: soft/outline`、`size: sm/md`、`icon`、`dot=true`，以及原生 span 属性。默认不是 live region，避免状态标签大量重复播报。 |
| `StatCard` | `label`、`value` | `unit`、`icon`、`description`、`trend:{label,direction:up/down/neutral,tone?}`、`loading`、`footer`、`className`。趋势方向与好坏分开，数字格式由应用提供。 |

操作流程组件：

| 组件 | 必填属性 | 可选属性与行为 |
| --- | --- | --- |
| `StepWizard` | `label`、`steps`、`currentStep`、`onStepChange`、`onComplete` | 步骤含 `id/title/content/description?/icon?`。`completedSteps`、`onBeforeNext`、`completed`、`completedContent`、`completeLabel`、`disabled`、`operationKey`、`className`。步骤与完成状态受控，内容保持挂载。 |
| `ConfirmDialog` | `triggerLabel`、`title`、`description`、`onConfirm` | `confirmLabel/cancelLabel`、`confirmationText`、`tone: accent/danger`、`open/onOpenChange`、`operationKey`、`disabled`、`children`、`className`。默认焦点在取消；可要求精确文字确认。 |
| `NotificationCenter` | `items` | `label`、`onReadChange(ids,read)`、`onDismiss(id)`、`onAction(id)`、`filter/onFilterChange`、`busy`、`error`、`className`。消息、已读和移除结果由应用传入；阅读筛选不自动标已读。 |
| `CommandPalette` | `items`、`onAction(id)` | `triggerLabel/title/description/placeholder`、`open/onOpenChange`、`query/onQueryChange`、`operationKey`、`className`。搜索名称、说明与关键词，复用 Base UI 键盘和焦点处理。 |

基础 API：

| API | 用途 |
|---|---|
| `SakuraProvider` | 向控件提供明暗模式、配色和动效设置。 |
| `ToastProvider` | 提供通知层；放在 SakuraProvider 内，可设 `duration=5000` 毫秒和 `limit=3`。 |
| `useToast()` | 返回 `notify(options): string` 和 `dismiss(id?)`；未传 ID 时关闭全部通知。 |
| `useSakuraMotion()` | 读取当前主题、CSS 变量和动效配置，用于组合应用专属界面。 |
| `useDownloadTask(execute)` | 下载状态、启动、防重复操作、取消、停止等待与重试。 |
| `useSharedDraft(snapshot, options?)` | 按实体保护本地草稿、焦点与输入法，处理保存回执和版本冲突；不自动保存。 |
| `useActivityFollow({view,viewer,onViewerChange,protecting?})` | 将已确认的呈现提示合并到当前观看状态，返回 `registerRegion(id)` 与 `highlightedRegionId`；不发命令、不移动键盘焦点。 |
| `createBrowserDownloadExecutor(resolver)` | 将 Blob 或同源地址交给浏览器原生下载。 |
| `themePresets` / `parseTheme` / `serializeTheme` / `themeToStyle` | 主题选择、验证、文件序列化与 CSS 变量映射。 |

Select 与 ActionMenu 由 Base UI 提供键盘、定位与焦点行为。禁用项可以获得键盘焦点，以便辅助技术告知不可用状态，但不能选择或执行。可搜索的多选场景使用 `SearchSelect`；它同样由 Base UI Combobox 管理输入法、焦点与选择，不自行拦截 Enter。组件取消 Esc 对已选值的隐式清空，Esc 只退出搜索；标签通过移除按钮或 Backspace 删除。

`SearchSelect` 的 `maxSelected` 限制新增：达到上限后，仍可移除已有值。应用传入的已有值不会因为选项暂时为空、选项被移除或上限下降而静默丢失；未知值显示其原值，仍能显式移除。`style` 中的字体、字号、颜色与 CSS 自定义变量会传到弹层，宽度等布局属性留在字段外层。

## 组织内容与反馈的最小示例

`ToastProvider` 放在 `SakuraProvider` 内；调用 `useToast()` 的组件必须是它的后代。通知选项为 `{ title, description?, tone?: success / info / warning / error, action?: { label, onClick }, duration? }`。`duration: 0` 持续展示到关闭，带操作的通知在未指定时长时至少保留 8 秒。

```tsx
import { useState } from 'react';
import {
  SakuraProvider, ToastProvider, useToast, MotionTabs, SearchSelect,
  RangeField, ActionMenu, DrawerPanel, Hint, Button,
} from '@sakura-ui/react';

export function Demo() {
  return <SakuraProvider theme="light" motionPreset="soft">
    <ToastProvider><Content /></ToastProvider>
  </SakuraProvider>;
}

function Content() {
  const { notify } = useToast();
  // 需要跨页签保留的状态放在 MotionTabs 上方。
  const [tab, setTab] = useState('edit');
  const [tags, setTags] = useState<string[]>([]);
  const [strength, setStrength] = useState(40);
  const [drawerOpen, setDrawerOpen] = useState(false);
  return <>
    <MotionTabs label="资料内容" value={tab} onValueChange={setTab} items={[
      { value: 'edit', label: '调整', content: <>
        <SearchSelect label="资料标签" values={tags} onValuesChange={setTags}
          maxSelected={3} options={[
            { value: 'color', label: '色彩', description: '配色与材质' },
            { value: 'motion', label: '动效', description: '连续的变化' },
          ]} />
        <RangeField label="预览强度" value={strength} onValueChange={setStrength}
          min={0} max={100} step={5} formatValue={(value) => `${value}%`} />
      </> },
      { value: 'summary', label: '概况', content: <p>已选 {tags.length} 项，强度 {strength}%。</p> },
    ]} />
    <ActionMenu label="资料操作" items={[
      { id: 'copy', label: '复制链接' },
      { id: 'remove', label: '移除', tone: 'danger', separatorBefore: true },
    ]} onAction={(id) => notify({ title: `选择了演示操作：${id}`, tone: 'info' })} />
    <DrawerPanel triggerLabel="查看完整资料" title="资料详情" description="保留列表上下文"
      open={drawerOpen} onOpenChange={setDrawerOpen}
      footer={<Button onClick={() => setDrawerOpen(false)}>完成</Button>}>
      <p>在这里呈现更长的详情或相关设置。</p>
    </DrawerPanel>
    <Hint content="在当前设备记住这套偏好。">
      <Button onClick={() => notify({ title: '演示通知', description: '此示例没有保存业务数据。', tone: 'success' })}>保存演示</Button>
    </Hint>
  </>;
}
```

`MotionTabs` 只挂载活动页签，切走会卸载其中的输入框、内部状态和弹层。需要保留的值应像示例一样提升到外层，再通过属性传回；不要依赖离场动画保留业务状态。应用路由变化时也应同步关闭受控浮层，避免新页面出现上一页的对话框。

`Hint` 中只能放非必要的补充信息，按钮名称和完成任务所需的说明应在页面上可见。不要将表单、链接等需要操作的内容放进 Tooltip；使用 `FloatingPanel` 或 `FocusDialog`。同理，重要错误、待处理事项应有页面内的持续入口，Toast 适合短暂反馈，不能成为唯一的功能入口。

## 表单、流程与加载状态

```tsx
import { useState } from 'react';
import {
  TextField, CheckboxCards, DateField, StepFlow, ProgressBar,
  EmptyState, Skeleton, Button,
} from '@sakura-ui/react';

// 在 SakuraProvider 内使用；这里只演示本地状态，不接业务请求。
export function FormDemo() {
  const [name, setName] = useState('灵感资料');
  const [choices, setChoices] = useState<string[]>(['preview']);
  const [date, setDate] = useState<string | null>(null);
  const [step, setStep] = useState('details');
  const [loading, setLoading] = useState(false);

  return <>
    <TextField label="资料名称" name="resource-name" value={name}
      onChange={(event) => setName(event.currentTarget.value)}
      description="这会成为资料的显示名称。"
      error={name.length < 2 ? '至少输入两个字符。' : undefined}
      maxLength={30} showCount required />
    <CheckboxCards label="呈现偏好" values={choices} onValuesChange={setChoices}
      allowSelectAll options={[
        { value: 'preview', label: '显示预览', description: '先看内容，再决定是否打开' },
        { value: 'motion', label: '连续动效', description: '衔接每一次操作' },
        { value: 'reserved', label: '暂未开放', disabled: true },
      ]} />
    <DateField label="整理日期" value={date} onValueChange={setDate}
      min="2026-01-01" max="2027-12-31" />
    <StepFlow label="整理流程" currentStep={step} onStepChange={setStep}
      completedSteps={step === 'review' ? ['details'] : []} steps={[
        { id: 'details', title: '填写资料' },
        { id: 'review', title: '检查预览' },
      ]} />
    <Button onClick={() => setStep('review')} disabled={name.length < 2}>检查预览</Button>
    <ProgressBar label="示例完成度" value={step === 'review' ? 100 : 50}
      tone={step === 'review' ? 'success' : 'accent'} />
    {loading ? <section aria-label="预览加载状态" aria-busy="true">
      <p role="status">正在准备演示预览…</p>
      <Skeleton width="65%" />
      <Skeleton shape="rect" height={100} />
      <ProgressBar label="准备演示预览" />
      <Button variant="secondary" onClick={() => setLoading(false)}>结束演示加载</Button>
    </section> : <EmptyState title="还没有预览" description="从下面的入口体验加载状态。"
      action={<Button onClick={() => setLoading(true)}>模拟加载</Button>} />}
  </>;
}
```

`TextField` 的 ref 直接指向原生 input；`onChange`、输入法组合事件、`type`、`autoComplete`、`name`、`required` 等保持原生行为。错误与说明会合并进 `aria-describedby`，错误出现时设为 `aria-invalid`；错误动画只改变旁边的说明区，不重挂输入框。`showCount` 按原生 `maxLength` 的 UTF-16 长度计数，支持受控值与非受控表单重置；不会截断应用传入的受控值。密码仅透传 `type="password"`，未内置可见性切换。

`CheckboxCards` 的“全选可用项”只增加或移除未禁用选项。已选的禁用项和暂未出现在选项列表中的值会保留，不因全选、清空列表或换布局丢失。半选同时使用真实的 `input.indeterminate` 和可访问状态。选项和应用状态由调用者管理，业务校验不放进卡片组件。

`DateField` 使用不带时区的年月日模型，不经过 UTC 字符串转换。无效值与超出范围的已有值显示错误，不静默纠正；无效日期范围会禁用选择入口。方向键移动日期，Home/End 移到当周边界，Page Up/Down 切月，Shift 加 Page Up/Down 切年，Esc 关闭并返回入口。“回到今天”移动日历位置，仍需显式选择日期。

`StepFlow` 的完成状态由 `completedSteps` 明确传入，不按步骤位置推断业务已完成。`ProgressBar`、`Skeleton` 只反映应用已有的加载状态；未知进度可使用持续指示，但在关闭动效或系统减少动态效果时静止显示。`ProgressBar paused` 暂停未知进度动画并显示暂停状态，依然不设置虚假的 `aria-valuenow`。Skeleton 不创建读屏噪声，应用应在内容容器标记 `aria-busy`，并给出一处简短加载说明。

## 下载到不同位置

`DownloadPanel` 只展示 `targets` 提供的目标。同一种方式可配置多个机器；一个面板每次选择一个目标。只支持本机的项目传一个 `browser`，只支持 WebDAV 的项目可只传一个 `webdav`，不需要修改组件内部逻辑。

```tsx
import { useMemo } from 'react';
import {
  DownloadPanel, createBrowserDownloadExecutor,
  type DownloadTarget,
} from '@sakura-ui/react';

const targets: DownloadTarget[] = [
  { id: 'current-device', kind: 'browser', label: '本机下载' },
];

export function DownloadExample() {
  const execute = useMemo(() => createBrowserDownloadExecutor(() =>
    new Blob(['可以带走的内容'], { type: 'text/plain;charset=utf-8' })
  ), []);
  return <DownloadPanel
    resource={{ id: 'example', label: '示例文件', fileName: 'example.txt' }}
    targets={targets}
    execute={execute}
  />;
}
```

在 `SakuraProvider` 内使用。远端配置可以是：

```ts
const remoteTargets: DownloadTarget[] = [
  { id: 'web-downloads', kind: 'server', label: '服务端下载',
    machineLabel: 'Web 服务机器', executionLabel: 'Web 服务机器', storageLabel: 'Web 服务机器',
    rootLabel: '/srv/downloads', defaultDirectory: 'inspiration' },
  { id: 'remote-downloads', kind: 'webdav', label: '远程文件库',
    machineLabel: '远程存储', executionLabel: '外部 Web 服务', storageLabel: '远程文件库',
    rootLabel: '/Downloads', defaultDirectory: 'inspiration' },
];
```

`executionLabel` 表达谁执行传输，`storageLabel` 表达最终存储设备；两者可以不同。兼容字段 `machineLabel` 仍为远端目标必填项，用作存储说明后备值，也作为 server 方式的执行说明后备值；WebDAV 没有执行说明时显示“由接入应用指定”，不把存储设备推断为执行设备。

这些标签与 `rootLabel` 仅用于显示；`id` 必须稳定对应后端已配置且当前用户有权访问的存储目标，更换实际映射时应使用新的 ID。请求携带 `resourceId`、`targetId`、`fileName`、`destination.kind/relativeDirectory`、`collision` 和 `requestId`，不携带密码或任意根目录。选择的目标被移除或禁用后不会自动改投其他位置。浮窗重挂后若只保留了请求而没有原设备显示信息，组件将明确标为“当前配置参考”，不把当前标签当成原任务真实落盘证明。

应用实现 `DownloadExecutor(request, {signal, onProgress})` 并传给 `execute`。服务端磁盘写入、源文件解析、权限、根目录真实路径检查、WebDAV 凭据、任务存储由接入项目负责；前端校验不是服务端安全边界。组件不直接访问远端文件系统，不用本机目录选择器表示远端目录。同名策略支持重命名和跳过，不提供隐式覆盖。

| 返回结果 | 界面含义 |
| --- | --- |
| `completed` | 目标已确认保存完成 |
| `submitted` | 已提交任务，可附带 `jobId`；尚未完成 |
| `handed-off` | 已交给浏览器，需要在原生下载列表确认结果 |
| `cancelled` | 执行器明确确认取消 |
| `interrupted` | 停止等待，目标状态未确认 |

`onProgress` 接收 `phase`（preparing/transferring/saving）、已传输字节与可选总字节；没有总字节时显示不确定进度。只有服务端明确回报保存成功才返回 `completed`。模拟执行器应返回 `simulated: true`。

`useDownloadTask(execute)` 返回 `state/start/cancel/stopWaiting/reset/retry`。取消只发出中断信号，执行器必须实现远端取消确认；用户可在未确认时停止等待。重试保留冻结请求、原执行器和 `requestId`，后端仍须用该标识防止重复写入。重新配置后发起的新任务获得新标识。

需要关闭浮窗后继续显示任务时，将 `useDownloadTask` 放在浮窗外，把返回值传给 `DownloadPanel controller={task}`。跨路由继续任务时须再提升到路由之外；卸载控制器会请求中断等待，不保证远端已取消。`onStateChange` 可观察状态变化，不能当作网络完成的替代证据。

`createBrowserDownloadExecutor` 接收返回 Blob 或同源 HTTP(S)/blob URL 的解析函数；URL 直接交给浏览器，不先将大文件读入前端内存。跨源地址应由应用提供同源下载入口。它返回 `handed-off`，不能指定浏览器设备的任意磁盘路径、追踪原生进度或证明实际落盘。组件自身创建的 Blob URL 延迟清理，外部提供的 Blob URL 由调用方维护。

Studio 入口：`/#/components?section=download`。本机示例生成小 JSON 文件；服务端与 WebDAV 为明确标注的模拟执行器。详细设计与后端接入边界见 [下载组件设计](../../../docs/design-foundation/download-design.md)。

## 外部状态驱动、观看与人工草稿

`DownloadPanel` 保留本地单次执行的简便接口；远端业务系统使用 `DownloadForm`、`useSharedDraft` 和 `TaskCollection` 组合。业务快照进入组件只更新显示；人工编辑、保存、提交和取消通过回调报告意图，应用调用服务，服务确认后再传回事实。禁止在 `onStateChange` 或接收快照的 effect 中调用 `start/submit/retry`。

将 `useSharedDraft.inputProps` 放在表单共同父容器时，进入 React 逻辑子树内的 Portal 继续算同一次编辑，不会在触发器失焦的瞬间采用外部草稿。真正离开才解除焦点保护。草稿缓存属于 hook 实例；跨卸载需要由应用提升控制器或保留备份，保存待确认也应算备份条件，不能只检查 `dirty`。

`ActivitySurface` 收起会保留字段节点；内部的 `SelectField` 同步关闭弹层，重新展开不会自动打开，也不把焦点送回隐藏字段。收起不改变原生表单中已填的值，`disabled` 仍只由调用方决定。其他 Portal 组件的嵌套组合尚未统一适配，接入时需验证各自关闭逻辑，不将 DOM 的 `inert` 当成所有外置弹层都会关闭的保证。

以下最小组合在 `SakuraProvider` 内运行；调用方提供已经确认的快照与保存函数，不要求使用 HTTP。相同组合可以放下载字段，也可以放文件整理字段。

```tsx
import { useState } from 'react';
import {
  ActivitySurface, FollowControls, SharedDraftPanel, TextField,
  useActivityFollow, useSharedDraft,
  type ActivityFollowView, type ViewerState,
  type SharedDraftSnapshot, type SharedDraftSaver,
} from '@sakura-ui/react';

type Parameters = { folderName: string };

export function ObservableEditor({ view, snapshot, save }: {
  view: ActivityFollowView;
  snapshot: SharedDraftSnapshot<Parameters>;
  save: SharedDraftSaver<Parameters>;
}) {
  const [viewer, setViewer] = useState<ViewerState>({
    activityId: view.activityId, mode: 'follow', expandedSurfaceIds: ['draft'],
  });
  const draft = useSharedDraft(snapshot);
  const follow = useActivityFollow({
    view, viewer, onViewerChange: setViewer, protecting: draft.protecting,
  });
  return <>
    <FollowControls mode={viewer.mode}
      onModeChange={(mode) => setViewer((value) => ({ ...value, mode }))} />
    <ActivitySurface regionId="draft" title="操作参数"
      ref={follow.registerRegion('draft')}
      expanded={viewer.expandedSurfaceIds.includes('draft')}
      highlighted={follow.highlightedRegionId === 'draft'}
      onExpandedChange={(expanded) => setViewer((value) => ({ ...value,
        expandedSurfaceIds: expanded ? ['draft'] : [],
      }))}>
      <SharedDraftPanel {...draft.inputProps}
        revision={draft.baseRevision} dirty={draft.dirty} pending={draft.pending}
        conflictRevision={draft.conflict?.revision} error={draft.error}
        onSave={() => { void draft.submit(save); }}
        onAcceptLatest={draft.acceptLatest} onRebase={draft.rebase}>
        <TextField label="整理后的文件夹" value={draft.value.folderName}
          onChange={(event) => draft.change({ folderName: event.currentTarget.value })} />
      </SharedDraftPanel>
    </ActivitySurface>
  </>;
}
```

`SharedDraftSnapshot<T>` 是 `{id,revision,value}`；`SharedDraftSaver<T>` 接收 `{value,expectedRevision}` 并返回服务确认后的同实体快照。`useSharedDraft` 返回 `value/baseRevision/dirty/conflict/pending/error/protecting`、`change`、`inputProps`、`acceptLatest`、`rebase`、`submit`。默认支持可 `structuredClone` 的普通数据；特殊领域对象可通过 `clone/isEqual` 自定义。

把 `inputProps` 放在表单共同父容器，接收冒泡的焦点和输入法组合事件。聚焦、中文输入组合、未保存修改与保存等待期间，新快照只记录为最新版本，不覆盖本地值。不同实体按稳定 `id` 分开保留本地草稿；不要用版本号作为 React key 来强制重挂输入。保存中的新输入也不会被旧回执清空。`acceptLatest()` 明确替换为后台最新版；`rebase()` 保留全部本地值，只把并发基线换到最新版本，仍需再次保存。它不自动合并字段，也不授予覆盖权限。冲突期间 `submit` 返回 false，不发送保存调用。

下载字段可替换为下列受控内容。`downloadDraft` 为 `useSharedDraft<DownloadDraft>` 的结果，`resource/targets` 由应用提供。由外层 `SharedDraftPanel` 管理保存，因此隐藏表单自身提交按钮；创建远端任务使用另一显式按钮，只提交已确认的草稿版本。

```tsx
<DownloadForm resource={resource} targets={targets}
  value={downloadDraft.value} onValueChange={downloadDraft.change} hideSubmit />
```

独立使用时，`DownloadForm onSubmit` 在用户提交且字段校验通过后收到规范化的 `DownloadDraft`；仅校验文件名、已配置目标和相对目录，不产生 requestId、不启动执行器、不判断服务端权限。切换目标时应用通过 `onValueChange` 接收新目录；需要每个目标独立保留未保存参数时，由调用方缓存。

`ViewerState={activityId,mode,expandedSurfaceIds}` 只属于当前浏览器。`ActivityFollowView={activityId,viewRevision,presentation?}` 中，提示是 `{id,regionId,effect: reveal / locate / highlight}`；必须映射到 `registerRegion` 登记的区域。外部事件不能自动换观察对象。暂停跟随只停自动展开、定位与强调，任务事实继续更新；恢复只采用最新提示。保护输入期间即使选择恢复跟随，也先保留人工草稿，显式处理后再定位。hook 不调用 focus，不执行服务命令；减少动态效果时定位不使用平滑滚动。

| 编号 | 所属层 | 用途 |
| --- | --- | --- |
| `epoch + seq` | 应用传输适配层 | 区分服务会话、去重、丢弃旧快照；组件不订阅网络 |
| `viewRevision` | 活动展示 | 接受更新的呈现提示，快速事件收敛到当前状态 |
| 草稿 `revision` / 任务 `entityRevision` | 业务实体 | 保存、提交和控制动作的并发检查；进度不改变草稿版本 |

`TaskCollectionItem` 必填 `id/title/status`，可选 `statusLabel`、`progress:{value?,max?,label?,description?}`、`detail`、`attempt`、`retryOf`、`simulated`、`actions`。状态支持 `queued/submitted/running/cancelling/completed/failed/cancelled/interrupted/handed-off/paused`。每个 action 是 `{id,label,disabled?,reason?,pending?}`；调用方将真实能力转换为动作列表，缺少取消能力时隐藏或禁用并说明原因。未知总量可传仅含 label 的 progress；不能补出百分比。点击取消后只标 pending 或等待确认，收到服务终态才显示 cancelled。

`useDownloadTask.retry()` 复用原 requestId，适合确认不明时防重复提交；服务已经确认失败后的重试应创建新的任务 ID 与 attempt，并用 retryOf 关联原任务。服务返回任务集合直接驱动 `TaskCollection`，不要为了展示进度而重新调用下载执行器。

`OperationTimeline` 只解释已发生的事实。`onLocate` 用于查看记录关联区域，不重放搜索或下载；只有应用确实保存历史快照时才能提供历史状态回看。`FollowControls` 的接管按钮只发请求，pending、confirmed、rejected 由业务回执决定，与暂停跟随无关。

实验场提供下载与文件整理两个领域，复用同一套观看、草稿、任务和时间线。仓库根目录分别运行 `npm run dev:live` 和 `npm run dev`：前者启动 4318 本机演示服务，后者启动 4317 Studio 并代理 `/api/live`。HTTP/SSE 与独立客户端请求真实执行，内容与文件操作明确模拟；服务只用内存，重启清空并更换 epoch。通用组件包不依赖这个服务，也不依赖 HTTP/SSE。接入结构及验证边界见 [动态活动设计](../../../docs/design-foundation/activity-design.md) 与 [演示服务说明](../../apps/lab/server/README.md)。

## 下拉框定制示例

```tsx
import { useState } from 'react';
import { SelectField, type SelectFieldStyle } from '@sakura-ui/react';

const fieldStyle: SelectFieldStyle = {
  fontFamily: '"Noto Serif SC", "Songti SC", serif',
  fontSize: 16,
  color: 'var(--sk-ink)',
  '--sk-select-accent': 'var(--sk-accent-2)',
  '--sk-select-accent-soft': 'var(--sk-accent-2-soft)',
  '--sk-select-background': 'var(--sk-surface-raised)',
  '--sk-select-menu-background': 'var(--sk-surface-overlay)',
  '--sk-select-radius': '14px',
};

export function ColorfulSelect() {
  const [value, setValue] = useState('focus');
  return <SelectField
    label="阅读氛围"
    value={value}
    onValueChange={setValue}
    size="lg"
    style={fieldStyle}
    options={[
      { value: 'focus', label: '专注', description: '让内容更清晰', icon: <span>◌</span> },
      { value: 'gentle', label: '轻柔', description: '留一点呼吸感', icon: <span>◇</span> },
    ]}
  />;
}
```

字体是否存在取决于应用环境，本库不下载字体。`fontFamily`、`fontSize`、`fontWeight`、`color` 与传入的 CSS 自定义变量会复制到弹层；宽度、边距等布局属性只应用在字段外层，避免污染弹层定位。

组件点缀色会用于图标、选中项、聚焦环、悬停/展开边框及展开柔光。还可单独覆盖 `--sk-select-color`、`--sk-select-border`、`--sk-select-focus-ring`、`--sk-select-hover-border`、`--sk-select-active-border`、`--sk-select-menu-radius`。选项图标与选中文字取 `--sk-select-accent`（默认 `--sk-accent-text`）；高亮背景取 `--sk-select-accent-soft`，未设置时由点缀色在浮层表面上派生。旧别名 `--sk-select-icon-color`、`--sk-select-option-selected-background`、`--sk-select-soft`、`--sk-select-selection` 已不再读取，请改用这两个变量。菜单默认底色是 `--sk-surface-overlay`。自定义颜色之后仍需检查实际对比度。

## 选择适合的交互

| 需求 | 建议组件 | 使用边界 |
|---|---|---|
| 从少量明确选项中选择一个值 | `SelectField`；选项更少且希望全部可见时用 `FluidSegmented` | 标签与当前值留在页面中，不把多字段任务藏进下拉菜单。 |
| 搜索并选择多个标签或对象 | `SearchSelect` | 输入筛选，已选值保留为标签；对长列表有帮助，选项 ID 需稳定。 |
| 对当前对象执行复制、移除等命令 | `ActionMenu` | 使用 menu 语义，执行后关闭；不能拿它替代选择值的 Select。 |
| 在同一对象的相关内容之间切换 | `MotionTabs` | 页签代表内容区域，状态由应用提升管理；应用级导航仍由路由与 SidebarNav 负责。 |
| 连续调整一个范围内的数值 | `RangeField` | 提供单位与当前值，应用给出合理的范围和步长。 |
| 输入短文本、邮箱等原生表单值 | `TextField` | 保留原生输入法与表单行为，校验信息由应用提供。 |
| 比较并勾选少量明确选项 | `CheckboxCards` | 让说明与图标一并可见；大量选项用 SearchSelect 筛选。 |
| 选择一个不带时间的日期 | `DateField` | 使用日期字符串；时间选择、时区换算和日期范围选择不属于当前接口。 |
| 呈现分阶段任务与完成状态 | `StepFlow` | 应用控制推进与校验，已完成步骤可回访。 |
| 显示等待、进度或没有内容 | `ProgressBar` / `Skeleton` / `EmptyState` | 区分工作未知进度、内容尚未加载和当前确实为空，不用加载动画掩盖错误。 |
| 就地调整少量偏好、查看简短关联内容 | `FloatingPanel` | 紧邻原入口完成，保留页面上下文。 |
| 阅读详情、编辑一组相关字段、完成需要暂时聚焦的短任务 | `FocusDialog` | 给出标题和说明，必要时指定初始/返回焦点；内容过长或任务独立时由应用使用独立页面。 |
| 浏览列表中的长详情或相关配置 | `DrawerPanel` | 侧边空间保留原页面的视觉位置；当前实现为模态，底下页面在关闭前不可交互。 |
| 对象本身具有可展开内容 | `MorphingSurface` | 原位展开有助于理解对象和内容的关系。 |

## 数据与文件的最小接入

```tsx
import { useState } from 'react';
import { DataTable, FileDropzone, StatCard, StatusBadge, type DataTableColumn } from '@sakura-ui/react';

type Item = { id: string; name: string; size: number };
const columns: DataTableColumn<Item>[] = [
  { id: 'name', header: '名称', cell: row => row.name, sortValue: row => row.name },
  { id: 'size', header: '大小', cell: row => row.size + ' MB', sortValue: row => row.size, align: 'end' },
];

export function ResourceView({ rows }: { rows: Item[] }) {
  const [selected, setSelected] = useState<string[]>([]);
  const [files, setFiles] = useState<File[]>([]);
  return <>
    <StatCard label="资源" value={rows.length} unit="项" />
    <StatusBadge tone="success">已准备</StatusBadge>
    <DataTable label="资源列表" rows={rows} columns={columns}
      getRowId={row => row.id} getRowLabel={row => row.name}
      searchText={row => row.name} pageSize={5}
      selectedIds={selected} onSelectionChange={setSelected} />
    <FileDropzone label="待加入的资料" files={files} onFilesChange={setFiles}
      accept="image/*,.pdf" maxFiles={4} maxSizeBytes={5 * 1024 * 1024} />
  </>;
}
```

表格用于本地已加载的数据；不是服务端分页协议或虚拟列表。`pageSize` 默认 5、最多 100 行，无效值回退默认。列由 `id/header/cell/sortValue?/align?/width?` 描述，行 ID 必须唯一且非空。只有提供 `sortValue` 的列显示排序入口，数字按数值比较，缺失值始终在最后，同值保持源顺序。

`query`、`sort`（`{columnId,direction}` 或 null）、`page` 可以分别由应用受控；未提供时使用组件本地状态。受控值若没有对应回调，界面按只读处理。外部数据变化只改变显示，不调用这些回调；数据减少时夹紧页码，不因恢复数据跳回旧越界页。服务端大列表应另行提供明确的服务端分页或虚拟化接入，不能仅把当前页数据当成全部 rows。

选择仅在提供 `selectedIds` 或 `onSelectionChange` 时显示。页头全选只操作当前页可选行，保留其他页、禁用项和未知 ID；外部 rows 更新不擅自清空选择。`isRowSelectable` 决定用户能否改变对应行选择，应用仍负责权限。`rowActions(row)` 可复用 ActionMenu，`toolbar` 可放应用自己的状态筛选。

FileDropzone 的 `files` 是受控的原生 File 数组；`onFilesChange` 只报告人工选择、拖入或移除。每次操作对不符合类型、大小、数量及重复文件给出拒绝原因；`onRejected` 返回 `{name,file?,code,message}[]`，code 为 type/size/count/duplicate/directory。保留原文件与本次合格文件，不因为一个失败而清空全部内容。不支持整目录拖入。

类型检查使用文件名扩展名和浏览器提供的 MIME，属于前端体验校验，不检查真实内容，也不替代服务器校验。文件不会自动上传、解析或持久化；刷新/离开页面后的文件生命周期由应用管理。父组件传入已有列表只更新显示，即使新上限低于已有数量，也不会擅自删除文件。

`StatCard` 的值不做虚构计数动画；loading 时隐藏旧数值、显示加载反馈。趋势 direction 与 tone 分开，下降也能是成功语义。状态标签始终需要文本，不用颜色独自表达状态；大量标签默认不增加读屏通知。

实验入口：`/#/components?section=data`，本分类不依赖活动演示服务。

## 操作流程的最小接入

```tsx
import { useState } from 'react';
import { StepWizard, ConfirmDialog, NotificationCenter, CommandPalette, type NotificationItem } from '@sakura-ui/react';

export function Workflow() {
  const [step, setStep] = useState('details');
  const [done, setDone] = useState(false);
  const [items, setItems] = useState<NotificationItem[]>([
    { id: 'welcome', title: '一份待看的说明', read: false, timeLabel: '本页演示' },
  ]);
  return <>
    <StepWizard label="配置流程" currentStep={step} onStepChange={setStep}
      completed={done} onComplete={() => setDone(true)}
      steps={[
        { id: 'details', title: '填写', content: <p>这里由应用提供字段。</p> },
        { id: 'review', title: '确认', content: <p>这里展示最终参数。</p> },
      ]} />
    <ConfirmDialog triggerLabel="清空本页通知" title="确认清空？"
      description="只影响这个演示列表。" confirmationText="清空" tone="danger"
      onConfirm={() => setItems([])} />
    <NotificationCenter items={items}
      onReadChange={(ids, read) => setItems(current => current.map(item => ids.includes(item.id) ? { ...item, read } : item))}
      onDismiss={id => setItems(current => current.filter(item => item.id !== id))} />
    <CommandPalette items={[{ id: 'back', label: '回到第一步', keywords: ['重新开始'] }]}
      onAction={() => { setStep('details'); setDone(false); }} />
  </>;
}
```

`StepWizard` 的 `onBeforeNext(stepId)` 可以同步或异步返回 true（继续）、false（留在原处，由应用呈现字段错误）或错误文字（在向导内显示）。只有用户前进才执行校验；外部切步不执行校验或提交。`completedSteps` 由应用明确给出，组件不猜测业务步骤已经完成；最终只有 `completed=true` 才展示完成内容。字段值由领域表单管理，返回步骤保留原节点；用户主动导航后会聚焦对应步骤标题，外部切步不主动抢焦点。

`onComplete`、`onConfirm` 和 `onAction` 支持 void 或 Promise<void>；异步等待期间防止重复操作，拒绝/throw 时显示错误并允许重试。不要用 false 或未检查状态码的 fetch 返回值表示失败：动作失败需要抛出明确错误。确认框和命令面板只在回调成功后请求关闭；执行中暂不允许通过界面关闭，长任务应在服务接受后返回并交给 TaskCollection 呈现后续进度。

涉及资源切换或草稿版本时，传入稳定且随上下文变化的 `operationKey`。旧校验不再触发新上下文的完成回调，旧确认回执不关闭新对象。组件丢弃过期界面回执不代表远端操作被取消；应用仍负责请求超时、业务幂等和真正取消。已发出的应用回调可能继续执行，不能用关闭界面代替服务确认。

`ConfirmDialog` 复用 Base UI AlertDialog，默认聚焦取消。`confirmationText` 为精确匹配，输入保存在当前操作会话；重新打开或对象变化会重置。外部设置 open 不执行确认。若应用保留受控 open=true，即使确认回调已完成，确认按钮也会锁定，避免同一会话再次执行。

`NotificationItem={id,title,read,description?,timeLabel?,tone?,icon?,pending?,action?:{label,disabled?}}`，列表按传入顺序呈现。时间标签由应用格式化，库不启动相对时间定时器。全部已读只报告未读且非 pending 的 ID；外部数据更新、打开和筛选均不自动标读。动作回调只是意图，接入实际服务时以返回的 items 确认状态，等待可设置 busy 或单项 pending。

`CommandPaletteItem={id,label,description?,keywords?,icon?,shortcut?,disabled?}`。支持输入法组合、方向键、Enter 和 Escape；禁用项不可执行。shortcut 仅为提示文本，组件不注册全局 Ctrl/Cmd+K；应用应协调全局热键及已有搜索入口。受控 query/open 的外部更新只改变显示，不执行操作。

纯前端演示入口：`/#/components?section=workflow`。只创建本页计划与示例消息，不调用后端、发送通知或删除真实资源。

## 打包与验证

在仓库根目录运行：

```sh
npm run check
npm run verify:package
```

`verify:package` 先构建组件库，再根据两个 workspace 的 `package.json` 以及 `npm pack --json` 的实际结果生成 tarball。它在 `artifacts/consumer-*` 创建独立消费项目，实际安装打包产物，使用全部组件，检查 TypeScript 声明、CSS 导出与生产构建，并运行已安装包的主题 JSON 往返验证。每次生成的独立项目都会保留，结果写入 `artifacts/package-verification.json`；脚本不发布、不删除目录。

验证子进程的 npm 缓存明确放在 `artifacts/npm-cache`，不改写全局 npm 配置，默认仍可联网解析依赖。已准备好所需缓存、需要离线运行时，在当前终端设置 `SAKURA_VERIFY_OFFLINE=1`，脚本会仅给 npm 子进程添加 `--offline`：

```powershell
$env:SAKURA_VERIFY_OFFLINE = '1'
npm run verify:package
```

离线运行会重新构建、重新打包并安装本次产物，缓存仅提供外部依赖，不复用旧组件包的验证结果。缺少必要依赖缓存时会明确失败；当前验证状态以新生成的结果文件及时间为准。

需要手动打包时，在构建后分别执行 `npm pack --workspace packages/tokens` 与 `npm pack --workspace packages/ui`，由消费项目安装生成的两个实际文件。包保留 `private: true` 以避免误发布。

当前验证覆盖 React 客户端应用。主题工具的 Node 运行验证不等于 SSR 或 hydration 验证；尚未验证服务端渲染、Next.js 集成或跨框架运行。跨框架可复用的是 CSS 变量与主题数据规范，React 控件需要单独适配。
