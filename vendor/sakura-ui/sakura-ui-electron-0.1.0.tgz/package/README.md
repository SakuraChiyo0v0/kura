# @sakura-ui/electron

Electron 系统能力：主进程公共能力、preload 桥，以及两侧共用的跨进程契约。界面部分在 [@sakura-ui/electron-react](../electron-react/README.md)。

| 子路径 | 运行在 | 内容 |
| --- | --- | --- |
| `@sakura-ui/electron/shared` | 两侧 | 基础工具（Emitter、超时、错误序列化）与契约：窗口控制 / 设置 / 自动更新 API 的类型与通道常量 |
| `@sakura-ui/electron/main` | 主进程 | 单实例锁、IPC 路由、窗口状态持久化、多窗口、托盘、设置存储、自动更新 |
| `@sakura-ui/electron/preload` | preload | 用 contextBridge 把上面三组 API 暴露给渲染层 |

依赖方向固定为 `main → shared`、`preload → shared`，shared 不依赖任何包。主进程代码只用 Electron 的**类型**，运行时不 import `electron`，Electron 实例由调用方注入。

## 设计约定

- **IPC 统一信封**：`createIpcRouter` 注册的处理器永远返回 `IpcResponse<T>`，主进程抛出的异常会转成结构化错误，由 preload 侧的 `unwrapIpcResponse` 拆包还原成 `Error`。渲染层因此不用面对「堆栈丢失」和「有的通道抛、有的通道返回错误码」两种风格。
- **处理器第一个参数是事件**：与 Electron 原生 `ipcMain.handle` 一致。多窗口场景靠它定位调用方（`BrowserWindow.fromWebContents(event.sender)`），否则第二个窗口的按钮会控制到第一个窗口上。不需要事件的处理器少写几个参数即可。
- **一次注册、逐窗口跟踪**：窗口控制通道全局只注册一次；窗口自身的事件（最大化、几何变化）是「每窗口」的事，每个窗口创建后各自挂在窗口上。
- **依赖注入**：主进程模块都只要求最小的接口（`IpcMainLike`、`ManagedWindowLike`、`TrayLike`、`UpdateBackend` 等），测试里用假实现即可，不需要真的启动 Electron。
- **兼容性钉在编译期**：`src/main/electron-compat.typecheck.ts` 断言真实的 `App` / `BrowserWindow` / `IpcMain` / `IpcRenderer` / `ContextBridge` 以及 electron-updater 的 `AppUpdater` 能直接传给库的接口。类型一旦对不上，`npm run typecheck` 就失败，而不是逼使用方到处写 `as unknown as ...`。

## 接入

### 主进程

```ts
import { join } from 'node:path'
import { BrowserWindow, app, ipcMain } from 'electron'
import {
  acquireSingleInstanceLock,
  createIpcRouter,
  createSettingsStore,
  createWindowManager,
  createWindowStateStore,
  registerSettingsIpc,
  registerWindowControls,
  trackWindowMaximizedChange,
  trackWindowState,
} from '@sakura-ui/electron/main'

const stateStore = createWindowStateStore(join(app.getPath('userData'), 'window-state.json'))
const settingsStore = createSettingsStore({
  file: join(app.getPath('userData'), 'settings.json'),
  defaults: { theme: 'dark', autoLaunch: false },
})
const router = createIpcRouter(ipcMain)

const windowManager = createWindowManager({
  create: (name) => {
    const window = new BrowserWindow({
      ...stateStore.readOr(name, { width: 1024, height: 720 }),
      frame: false, // 无边框，标题栏由渲染层负责
      show: false,
      webPreferences: { preload: join(__dirname, 'preload.js') },
    })
    trackWindowState({ window, name, store: stateStore }) // 尺寸/位置自动落盘
    trackWindowMaximizedChange(window) // 最大化状态推给这个窗口的渲染层
    window.once('ready-to-show', () => window.show())
    return window
  },
})

windowManager.ensure('main')

// 全局注册一次即可：处理器内部用事件定位调用方窗口
registerWindowControls({
  router,
  getWindow: (event) => BrowserWindow.fromWebContents(event.sender) ?? undefined,
})

registerSettingsIpc({
  router,
  store: settingsStore,
  broadcast: (channel, ...args) => windowManager.broadcast(channel, ...args),
})

acquireSingleInstanceLock({ app, onSecondInstance: () => windowManager.focus('main') })
```

### preload

```ts
import { contextBridge, ipcRenderer } from 'electron'
import { exposeSettings, exposeUpdater, exposeWindowControls } from '@sakura-ui/electron/preload'

exposeWindowControls({ contextBridge, ipcRenderer })
exposeSettings({ contextBridge, ipcRenderer })
exposeUpdater({ contextBridge, ipcRenderer })
```

渲染层接法见 [@sakura-ui/electron-react](../electron-react/README.md)。

## 能力清单

### 单实例锁

`acquireSingleInstanceLock({ app, onSecondInstance, onLockFailed })`：拿不到锁时默认直接 `app.quit()`，
第二个实例的启动参数会通过 `onSecondInstance` 交给已有实例（通常用来聚焦主窗口）。

### 窗口状态持久化

`createWindowStateStore(file)` 提供 `read / readOr / write / clear`，底层是一个 JSON 文件：读不到或内容损坏时退回默认值，写失败只告警不抛错。
`trackWindowState({ window, name, store, debounceMs })` 把窗口的尺寸、位置、最大化状态自动写进去——拖拽期间的 `resize / move` 做防抖，关闭时立即落盘。

### 多窗口

`createWindowManager({ create })` 维护「名字 → 窗口」的生命周期：

- `ensure(name)` 有则返回、无则创建；`get / focus / close`
- `closeAll()` 关闭全部，返回关闭数量
- `register(name, window)` 手动登记已创建的窗口，返回解除函数
- `broadcast(channel, ...args)` 向所有未销毁且有 `webContents` 的窗口发消息，返回实际送达数量

### 托盘

```ts
import { Menu, Tray, nativeImage } from 'electron'
import { createTrayManager } from '@sakura-ui/electron/main'

const tray = createTrayManager({
  create: () => new Tray(nativeImage.createFromPath(iconPath)),
  tooltip: '我的应用',
  onClick: () => windowManager.focus('main'),
  buildMenu: () =>
    Menu.buildFromTemplate([
      { label: '显示主窗口', click: () => windowManager.focus('main') },
      { type: 'separator' },
      { label: '退出', click: () => app.quit() },
    ]),
})

tray.ensure() // 惰性创建
tray.refresh() // 设置变化后重新应用 tooltip / 菜单（tooltip 传函数即可动态求值）
```

托盘常驻需要应用在窗口全关时不退出，这属于使用方的策略（`window-all-closed` 里自行判断），本库不代做决定。

### 设置

- 主进程：`createSettingsStore({ file, defaults })` → `all / get / set / patch / reset / onChange`
- IPC：`registerSettingsIpc({ router, store, broadcast })`，`broadcast` 通常直接传 `windowManager.broadcast`，改一处设置所有窗口同步
- 渲染层：见 [@sakura-ui/electron-react](../electron-react/README.md) 的 `useSettings` 与设置页版式

设置文件是单个 JSON：默认值与已存值浅合并，损坏时退回默认值，写入失败只告警。

### 自动更新

状态机与底层实现解耦：`UpdateBackend` 只需要 `check / download / install` 三个动作，库内置两个适配器，界面与状态流转完全一致。

```ts
import { autoUpdater } from 'electron'
import { autoUpdater as electronUpdater } from 'electron-updater' // 需自行安装
import {
  createBuiltinUpdaterBackend,
  createElectronUpdaterBackend,
  createUpdateManager,
  registerUpdaterIpc,
} from '@sakura-ui/electron/main'

const backend = useElectronUpdater
  ? createElectronUpdaterBackend({ updater: electronUpdater })
  : createBuiltinUpdaterBackend(autoUpdater)

const updateManager = createUpdateManager({
  backend,
  broadcast: (channel, ...args) => windowManager.broadcast(channel, ...args),
})

registerUpdaterIpc({ router, manager: updateManager })
```

渲染层用 `@sakura-ui/electron-react` 的 `useUpdater()` 加 `<UpdateBanner />`。

- 状态：`idle / checking / available / downloading（带进度）/ downloaded / up-to-date / error`，同一时刻只允许一次检查或下载，重复点按钮不会重复发请求。
- `createElectronUpdaterBackend({ updater })` 默认把 `autoDownload` 关掉，下载时机交给界面；检查结果从 `checkForUpdates()` 返回的 `updateInfo` 取版本号，进度来自 `download-progress` 事件。
- `createBuiltinUpdaterBackend(autoUpdater)` 走事件回调（`update-available / update-not-available / update-downloaded / error`）。内置实现没有下载进度事件，只能报出开始与完成；版本号取自事件的 `releaseName`，拿不到时显示「最新版本」。它只在 macOS / Windows 工作，且更新源与签名需要自己准备。
- 更新源配置（`setFeedURL` 或打包时写入）属于打包工具链的职责，本库不代劳。

## 关于依赖

### electron

`@sakura-ui/electron` 把 `electron` 声明为可选 peerDependency（只用 `/shared` 的渲染层不需要它），仓库内只在 devDependencies 装它用于**取类型**。
根 `package.json` 的 `allowScripts` 放行了 electron 与 esbuild 的安装脚本（npm 11 默认拦截），`npm ci` 会下载 Electron 运行时。
若安装时设置过 `ELECTRON_SKIP_BINARY_DOWNLOAD=1`（只想要类型、省 100MB+ 流量），之后需要真跑 playground 时，
进入 `node_modules/electron` 执行 `node install.js` 补下载。

### electron-updater

只有用 `createElectronUpdaterBackend` 的项目才需要安装它；用内置 `autoUpdater` 的项目完全不依赖它。
库里不 import 它的运行时代码，只在自己的类型检查里断言接口兼容，因此产物不会把 electron-updater 拖进依赖树。
