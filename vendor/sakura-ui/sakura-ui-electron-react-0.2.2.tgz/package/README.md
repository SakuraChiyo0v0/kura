# @sakura-ui/electron-react

Electron 渲染层组件：只放 Electron 才有意义的界面，以及把主进程能力接进 React 的 Hook。通用控件不在这里重写，直接用 [@sakura-ui/react](../ui/README.md)；系统能力来自 [@sakura-ui/electron](../electron/README.md)。

| 导出 | 用途 |
| --- | --- |
| `TitleBar` | 无边框窗口的标题栏，整条可拖拽，`actions` 放右侧按钮 |
| `WindowControls` | 最小化 / 最大化（还原）/ 关闭；拿不到 preload API 时自动禁用 |
| `UpdateBanner` | 自动更新状态条：检查、下载进度、安装 |
| `SettingsPage` / `SettingsSection` / `SettingsRow` | 设置页版式：标题、分组卡片、左文字右控件的行 |
| `useWindowControls` / `useSettings` / `useUpdater` | 读写主进程的窗口状态、设置与更新状态，跨窗口自动同步 |

## 安装与样式

需要 React 19，以及同版本的 `@sakura-ui/tokens`、`@sakura-ui/react`、`@sakura-ui/electron`。从交付目录（`npm run export:kit` 生成）安装四个 tgz，命令见交付目录里的 READ_FIRST.md；`electron` 由项目自行安装。样式按「地基 → 通用组件 → Electron 组件」的顺序各引入一次：

```ts
import '@sakura-ui/tokens/tokens.css'
import '@sakura-ui/react/styles.css'
import '@sakura-ui/electron-react/styles.css'
```

颜色、表面层级、填充色、圆角、字体、动效全部引用 `--sk-*` 地基变量，与网页产品同源；本包不写色值。类名前缀是 `sk-el-`，与通用组件的 `sk-` 区分。

## 渲染层

```tsx
import { SakuraProvider, SelectField, SwitchField } from '@sakura-ui/react'
import {
  SettingsPage,
  SettingsRow,
  SettingsSection,
  TitleBar,
  WindowControls,
  useSettings,
} from '@sakura-ui/electron-react'

export function App() {
  const { settings, set } = useSettings({ theme: 'light', autoLaunch: false, language: 'zh-CN' })

  return (
    <SakuraProvider theme={settings.theme} motionPreset="soft">
      <TitleBar title="我的应用" actions={<WindowControls />} />
      <main>
        <SettingsPage title="设置">
          <SettingsSection title="通用">
            {/* 开关本身就是「文字 + 控件」的一行，直接放进分组 */}
            <SwitchField
              label="开机自启"
              description="登录后在后台启动应用"
              checked={settings.autoLaunch}
              onCheckedChange={(value) => set('autoLaunch', value)}
            />
            {/* 下拉、输入放进 SettingsRow：行显示名称，字段自带标签只留给读屏 */}
            <SettingsRow
              label="语言"
              control={
                <SelectField
                  label="语言"
                  value={settings.language}
                  options={[
                    { value: 'zh-CN', label: '简体中文' },
                    { value: 'en-US', label: 'English' },
                  ]}
                  onValueChange={(value) => set('language', value)}
                />
              }
            />
          </SettingsSection>
        </SettingsPage>
      </main>
    </SakuraProvider>
  )
}
```

`SakuraProvider` 只接受 `light` / `dark`。设置里要提供「跟随系统」时，由应用监听 `prefers-color-scheme` 解析成实际亮暗再传入，写法见 `apps/electron-playground/src/renderer/App.tsx` 的 `useResolvedTheme`。

`<WindowControls />` 默认读取 preload 注入的全局 API；需要接自己的窗口控制实现时，通过 `control` 属性注入。

自动更新：

```tsx
const { status, check, download, install } = useUpdater()

<UpdateBanner status={status} onCheck={check} onDownload={download} onInstall={install} />
```

## 可覆盖的局部变量

这些只属于本包，不是地基变量：

| 变量 | 默认 |
| --- | --- |
| `--sk-el-titlebar-height` | `40px` |
| `--sk-el-titlebar-bg` / `--sk-el-titlebar-fg` | 表面混画布 / `--sk-ink` |
| `--sk-el-radius-sm` | `9px`（窗口按钮、更新条按钮） |
| `--sk-el-focus-ring` | 与通用控件同一画法 |

换配色、亮暗、动效请改 `SakuraProvider` 或地基，不要在这里覆盖 `--sk-*`。

## 真实验证

`apps/electron-playground` 是一个无边框 Electron 应用：主窗口 + 设置窗口，改设置两个窗口同步。

```bash
npm run build            # playground 消费已构建的包，先构建
npm run electron:smoke   # 冒烟：窗口控制 + 多窗口 + 设置广播 + 更新流程，输出 SMOKE ... => PASS
npm run start --workspace apps/electron-playground   # 打开窗口手动看
```

截图：设置 `PLAYGROUND_SCREENSHOT` 与 `PLAYGROUND_SCREENSHOT_SETTINGS` 为图片路径后启动，加载完成后各截一张并退出。

已知的坑：`ELECTRON_RUN_AS_NODE=1` 会让 Electron 以纯 Node 运行（`app` 为 undefined），启动前清掉；已有实例在跑时新实例会因单实例锁立即退出。
