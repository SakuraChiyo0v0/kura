# 发现项目材料或本地交付

在消费项目外也可运行；把 `<Skill目录>` 换成当前实际读取的 Skill 所在位置：

```sh
node "<Skill目录>/scripts/discover.mjs" --project "<消费项目目录>"
```

输出为 JSON：

- `ready`：selected 指明材料入口、查询和诊断脚本。kind=installed 使用已安装版本；kind=delivery 提供本项目需要的安装包路径且 requiresInstall=true。
- `needs-attention`：项目声明却安装损坏、配置无效或交付摘要/文件校验失败。先处理具体错误，不静默换版本。
- `not-found`：没有已安装材料或登记来源。请提供来源，不扫描其他项目或整块磁盘。
- `choose-source`：多份有效来源；用 `--source <id>` 明确选择。它不意味着安装或升级许可。

`profile` 按项目清单判断类型：声明了 `electron` 或任一 `@sakura-ui/electron*` 时为 `electron`，需要 tokens、react、electron、electron-react 四个包；否则为 `web`，只需前两个。delivery 只列出本项目需要的包，网页项目不会拿到桌面包；只含网页包的旧交付用于 Electron 项目时报 needs-attention。已安装网页包的 Electron 项目会在 `selected.missingPackages` 与 warnings 里列出还缺的桌面包。

ready 退出 0，普通未找到/需要处理退出 1，多来源待选择或参数错误退出 2。输出不包含安装命令，调用者仍需按当前任务授权与兼容诊断决定接入。

## 本机来源配置

可在已安装的个人 Skill 根目录创建 `sources.local.json`，或用 `--sources <文件>` 指定配置：

```json
{
  "version": 1,
  "sources": [
    { "id": "personal", "latest": "本机组件库/artifacts/deliveries/latest.json" }
  ]
}
```

latest 可以是绝对路径，或相对配置文件的路径。该文件只属于本机，不能放进组件库的便携 Skill 源目录、提交到他人项目或随包转发。当前工具读取明确登记的文件，不枚举工作区、账号或网络服务。

latest 指针需要来自维护者导出流程，包含 directory、version、passed 和 manifestSha256。发现工具核对摘要，再用自己的校验器检查目录完整性；不会执行候选目录中的 VERIFY.mjs。摘要保证与登记指针一致，不证明发布者身份。

已有项目版本优先，即使指定了来源，也不会自动切换或升级。祖先 node_modules 中可解析但当前项目没声明的包，不当作项目已接入。
