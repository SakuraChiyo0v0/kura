---
name: sakura-ui
description: 使用 Sakura UI 为 React 项目选用和组合组件，接入多色主题、动效及业务状态；适用于明确采用 Sakura UI 或要求复用这套个人组件库的任务。
---

# 使用 Sakura UI

先识别消费项目及已安装版本。遵守当前任务范围，接入此库不代表获准升级 React、迁移路由、发布包或部署项目。

## 定位材料

运行本 Skill 目录内的 `scripts/discover.mjs`，通过 `--project` 指定消费项目。它优先找项目已声明的安装版材料；未安装时读取本机 `sources.local.json` 登记的交付来源。只读，不扫描磁盘、不安装或升级。具体命令与配置见 [发现交付材料](references/discovery.md)。

读取结果的 `selected.entry`，再用 `selected.doctor` 检查接入环境；发现成功只代表材料可定位，不等于项目依赖或界面已经通过验证。保持已安装版本，不把发现另一份交付当作升级授权。

若尚未安装，从用户提供的材料目录取得同版本 `@sakura-ui/tokens` 与 `@sakura-ui/react` 安装包。不要假定它已公开发布到 npm；也不要硬编码维护者电脑路径。若本 Skill 随组件包一起读取，入口就在 `../START_HERE.md`（相对本文件）。缺少包或材料时明确报告所缺内容。

## 选用和实现

1. 阅读入口指向的 design-rules.md，将任务分成主要对象、可见动作、完成反馈与恢复路径。
2. 用入口中的 query.mjs 搜索用途并 `show 公共名称`，核对公共属性与业务边界；可直接查询 Hook、公开类型并沿 relatedTypes 继续阅读。必要时再查 dist 声明，不猜属性名。
3. 选取相关组合范例。底层组件从 `@sakura-ui/react` 导入；复制范例和配套 CSS 后由消费项目维护业务布局，不复制 Studio 的演示状态机和假执行器。
4. 主题由 SakuraProvider 提供。默认浅色、保留深色与多角色配色；实际项目已有偏好时以其为准。优先复用现有动效，减少动态效果设置仍然有效。
5. 写应用专属样式时只引用地基变量，按 design-rules.md 的「颜色与动效」选：表面层级（sunken / bg / surface / raised / overlay）、实心填充用 `-solid`、时长只用 `--sk-fast` / `--sk-settle`。不硬编码色值和毫秒数，不写 `var()` 兜底链；地基缺所需角色时记录为能力缺口，不在项目里另起一套。
6. Electron 项目另用 `@sakura-ui/electron`（main / preload / shared）与 `@sakura-ui/electron-react`。系统能力放主进程，经 preload 暴露，渲染层只调 Hook；通用控件仍用 `@sakura-ui/react`，不在 Electron 侧重写。用 `query.mjs electron` 与 `show` 查桌面接口，按契约里的 `runsIn` 把代码放进对应进程。网页项目不装这两个包。
7. 将外部数据与操作回调接进组件，区分提交成功、执行完成和浏览器接收下载。权限、凭据、真实路径与持久化保留在业务边界内。

## 验证和反馈

在消费项目运行类型检查与构建，并验证任务相关的错误、重试、关闭/重开和焦点行为。可用时在浏览器检查明暗与窄屏，受限制时明确未实测。

交付页面时说明复用了哪些组件/范例、业务实际接入到哪一步、发现什么能力缺口。不要把编译通过等同于用户满意，也不为了套用范例而增加当前产品不需要的功能。
