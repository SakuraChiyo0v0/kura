import { readFileSync, realpathSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, relative, isAbsolute, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

export function verifyDelivery(directory) {
  const root=realpathSync(directory);
  function inside(name) {
    if(typeof name!=='string' || !name || name.includes('\\') || name.includes(':') || name.includes('\0') || isAbsolute(name) || name.split('/').some(part=>!part || part==='.' || part==='..')) throw new Error('非法交付路径：'+name);
    const path=resolve(root,name);
    const rel=relative(root,path);
    if(!rel || rel.startsWith('..'+sep) || isAbsolute(rel)) throw new Error('路径超出交付目录：'+name);
    // Reject links at every level, including directory junctions.
    let cursor=root;
    for(const part of name.split('/')) { cursor=resolve(cursor,part);if(lstatSync(cursor).isSymbolicLink()) throw new Error('交付文件不允许符号链接：'+name); }
    const actual=realpathSync(path), actualRelative=relative(root,actual);
    if(actualRelative.startsWith('..'+sep) || isAbsolute(actualRelative) || !lstatSync(actual).isFile()) throw new Error('不是交付目录内的普通文件：'+name);
    return actual;
  }
  const manifest=JSON.parse(readFileSync(inside('manifest.json'),'utf8'));
  if(manifest.schemaVersion!==1 || typeof manifest.version!=='string' || !/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(manifest.version) || !Array.isArray(manifest.files) || !Array.isArray(manifest.packages)) throw new Error('不支持的交付清单');
  const names=new Set();
  for(const entry of manifest.files) {
    if(!entry || names.has(entry.path) || entry.path==='manifest.json' || typeof entry.sha256!=='string' || !/^[a-f0-9]{64}$/.test(entry.sha256) || !Number.isSafeInteger(entry.bytes) || entry.bytes<0) throw new Error('无效或重复文件清单');
    const bytes=readFileSync(inside(entry.path));names.add(entry.path);
    if(bytes.length!==entry.bytes || createHash('sha256').update(bytes).digest('hex')!==entry.sha256) throw new Error('文件校验失败：'+entry.path);
  }
  for(const required of ['READ_FIRST.md','VERIFY.mjs','ai/START_HERE.md','ai/catalog.json','ai/query.mjs','ai/doctor.mjs','ai/skill/SKILL.md']) if(!names.has(required)) throw new Error('清单缺少必要文件：'+required);
  // 网页两包必备；Electron 两包要么都在、要么都不在（旧交付只有前两个）。
  const base=['@sakura-ui/react','@sakura-ui/tokens'];
  const desktop=['@sakura-ui/electron','@sakura-ui/electron-react'];
  const packageNames=manifest.packages.map(pkg=>pkg.name);
  const hasDesktop=desktop.some(name=>packageNames.includes(name));
  const expected=hasDesktop?[...base,...desktop]:base;
  if(manifest.packages.length!==expected.length || new Set(packageNames).size!==expected.length || new Set(manifest.packages.map(pkg=>pkg.file)).size!==expected.length || expected.some(name=>!packageNames.includes(name))) throw new Error(hasDesktop?'Electron 交付必须同时包含 tokens、react、electron、electron-react 四个包':'必须包含两个不同的组件包');
  for(const pkg of manifest.packages) {
    if(!expected.includes(pkg.name) || pkg.version!==manifest.version || !names.has(pkg.file) || !pkg.file.endsWith('.tgz')) throw new Error('安装包版本或文件不一致');
  }
  const catalog=JSON.parse(readFileSync(inside('ai/catalog.json'),'utf8'));
  if(catalog.package!=='@sakura-ui/react' || catalog.version!==manifest.version || !Array.isArray(catalog.components) || !Array.isArray(catalog.recipes) || !Array.isArray(catalog.typeIndex) || !Array.isArray(catalog.apis)) throw new Error('AI 目录版本或结构与套件不一致');
  const publicTypes=new Set(catalog.typeIndex.map(item=>item.name));
  for(const entry of [...catalog.components,...catalog.typeIndex,...catalog.apis]) {
    const path='ai/'+entry.contract;
    if(!names.has(path)) throw new Error('缺少组件契约：'+path);
    const contract=JSON.parse(readFileSync(inside(path),'utf8'));
    if(contract.name!==entry.name || contract.version!==manifest.version) throw new Error('组件契约不一致：'+entry.name);
    for(const related of contract.relatedTypes || []) if(!publicTypes.has(related)) throw new Error('关联类型不存在：'+related);
  }
  for(const recipe of catalog.recipes) if(!names.has('ai/'+recipe.file)) throw new Error('缺少组合范例：'+recipe.file);
  // Electron 契约与网页契约分开校验：关联类型只在 Electron 自己的类型索引里找
  const electron=catalog.electron;
  if(hasDesktop && !electron) throw new Error('交付包含 Electron 包，但 AI 目录没有 Electron 契约');
  if(electron) {
    if(!Array.isArray(electron.components) || !Array.isArray(electron.typeIndex) || !Array.isArray(electron.apis)) throw new Error('Electron AI 目录结构不一致');
    // 类（如 Emitter）既是类型也是值，收在 apis 里，同样可以被关联
    const electronTypes=new Set([...electron.typeIndex,...electron.apis].map(item=>item.name));
    for(const entry of [...electron.components,...electron.typeIndex,...electron.apis]) {
      const path='ai/'+entry.contract;
      if(!names.has(path)) throw new Error('缺少 Electron 契约：'+path);
      const contract=JSON.parse(readFileSync(inside(path),'utf8'));
      if(contract.name!==entry.name || contract.version!==manifest.version || contract.importFrom!==entry.importFrom) throw new Error('Electron 契约不一致：'+entry.name);
      for(const related of contract.relatedTypes || []) if(!electronTypes.has(related)) throw new Error('Electron 关联类型不存在：'+related);
    }
  }
  return {passed:true,version:manifest.version,files:names.size,components:catalog.components.length,types:catalog.typeIndex.length,apis:catalog.apis.length,recipes:catalog.recipes.length,
    ...(electron?{electron:{packages:hasDesktop,components:electron.components.length,types:electron.typeIndex.length,apis:electron.apis.length}}:{})};
}

if(import.meta.url.startsWith('file:') && process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try { console.log(JSON.stringify(verifyDelivery(fileURLToPath(new URL('.',import.meta.url))),null,2)); }
  catch(error) { console.error('交付校验失败：'+error.message);process.exitCode=1; }
}
