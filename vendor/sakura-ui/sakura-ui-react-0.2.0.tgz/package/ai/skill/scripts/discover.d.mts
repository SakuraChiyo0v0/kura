export function discoverKit(options?: {project?:string;sources?:string;sourceId?:string}): {
  schemaVersion: number;
  project: string;
  status: string;
  /** 按项目依赖推断：Electron 项目需要四个包，网页项目两个。读不到清单时为 null。 */
  profile: {kind:'web'|'electron';packages:string[]} | null;
  selected: {kind:string;version:string;entry:string;query:string;doctor:string;requiresInstall:boolean;id?:string;directory?:string;packages?:{name:string;path:string}[];missingPackages?:string[]} | null;
  candidates: {id:string;kind:string;version:string;directory:string;requiresInstall:boolean}[];
  warnings: string[];
  failures: {id:string;message:string}[];
  automaticInstallation: boolean;
};
