import { readFileSync, existsSync, realpathSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { verifyDelivery } from './delivery-verifier.mjs';

const read=path=>JSON.parse(readFileSync(path,'utf8'));
export function discoverKit({project=process.cwd(),sources,sourceId}={}) {
  project=resolve(project);
  const warnings=[];const failures=[];
  // 读清单之前还不知道项目类型；之后会按 web / electron 重新定义 result
  let result=(status,selected=null,candidates=[])=>({schemaVersion:1,project,status,profile:null,selected,candidates,warnings,failures,automaticInstallation:false});
  let projectManifest;
  const projectFile=join(project,'package.json');
  if(existsSync(projectFile)) {
    try { projectManifest=read(projectFile);if(!projectManifest || typeof projectManifest!=='object' || Array.isArray(projectManifest)) throw new Error('清单需要是对象'); }
    catch(error){failures.push({id:'project',message:'无法读取项目清单：'+error.message});return result('needs-attention');}
  }
  const sections=['dependencies','devDependencies','peerDependencies','optionalDependencies'];
  for(const section of sections) if(projectManifest?.[section]!==undefined && (!projectManifest[section] || typeof projectManifest[section]!=='object' || Array.isArray(projectManifest[section]))) {
    failures.push({id:'project',message:section+' 必须是依赖声明对象'});return result('needs-attention');
  }
  const declares=name=>sections.some(section=>Object.hasOwn(projectManifest?.[section]||{},name));
  const declared=declares('@sakura-ui/react');
  // Electron 项目：声明了 electron 依赖或已装桌面包。只用于提示需要哪些包，不触发安装。
  const desktopProject=declares('electron') || declares('@sakura-ui/electron') || declares('@sakura-ui/electron-react');
  const desktopNames=['@sakura-ui/electron','@sakura-ui/electron-react'];
  const profile={kind:desktopProject?'electron':'web',packages:desktopProject?['@sakura-ui/tokens','@sakura-ui/react',...desktopNames]:['@sakura-ui/tokens','@sakura-ui/react']};
  result=(status,selected=null,candidates=[])=>({schemaVersion:1,project,status,profile,selected,candidates,warnings,failures,automaticInstallation:false});
  if(declared) {
    try {
      const resolver=createRequire(projectFile);
      const catalogPath=realpathSync(resolver.resolve('@sakura-ui/react/ai/catalog.json'));
      const entry=realpathSync(resolver.resolve('@sakura-ui/react/ai/START_HERE.md'));
      const catalog=read(catalogPath);const manifest=read(join(dirname(catalogPath),'../package.json'));
      if(manifest.name!=='@sakura-ui/react' || typeof manifest.version!=='string' || !manifest.version.trim() || catalog.package!==manifest.name || catalog.version!==manifest.version || catalog.schemaVersion!==1) throw new Error('安装包与材料版本不一致');
      const query=realpathSync(resolver.resolve('@sakura-ui/react/ai/query.mjs'));const doctor=realpathSync(resolver.resolve('@sakura-ui/react/ai/doctor.mjs'));
      if([entry,query,doctor].some(path=>dirname(path)!==dirname(catalogPath))) throw new Error('材料入口应位于同一安装包 AI 目录');
      if(sourceId) warnings.push('项目已有声明且可读取的材料，保持安装版本；来源参数不表示升级授权。');
      const missingDesktop=desktopProject?desktopNames.filter(name=>!declares(name)):[];
      if(missingDesktop.length) warnings.push('这是 Electron 项目，但尚未声明 '+missingDesktop.join('、')+'；需要标题栏、窗口按钮、设置同步或自动更新时从同版本交付安装。');
      return result('ready',{kind:'installed',version:manifest.version,entry,query,doctor,requiresInstall:false,missingPackages:missingDesktop});
    } catch(error) { failures.push({id:'installed',message:'项目声明了组件，但材料不可用：'+error.message});return result('needs-attention'); }
  }
  sources=resolve(sources || fileURLToPath(new URL('../sources.local.json',import.meta.url)));
  if(!existsSync(sources)) { warnings.push('此机器未登记交付来源，请提供交付目录或来源配置；不会扫描磁盘。');return result('not-found'); }
  let config;
  try {
    config=read(sources);
    if(config.version!==1 || !Array.isArray(config.sources)) throw new Error('需要 version:1 和 sources 数组');
    const ids=new Set();
    for(const source of config.sources) {
      if(!source || typeof source.id!=='string' || !source.id.trim() || ids.has(source.id) || typeof source.latest!=='string' || !source.latest.trim()) throw new Error('来源需要唯一 id 和 latest 文件路径');
      ids.add(source.id);
    }
  } catch(error) { failures.push({id:'configuration',message:'来源配置无效：'+error.message});return result('needs-attention'); }
  const candidates=[];
  for(const source of config.sources.filter(item=>!sourceId || item.id===sourceId)) {
    try {
      const pointerPath=resolve(dirname(sources),source.latest);const pointer=read(pointerPath);
      if(pointer.passed!==true || typeof pointer.directory!=='string' || typeof pointer.manifestSha256!=='string' || !/^[a-f0-9]{64}$/.test(pointer.manifestSha256)) throw new Error('不是已验证交付指针');
      const directory=realpathSync(resolve(dirname(pointerPath),pointer.directory));
      const digest=createHash('sha256').update(readFileSync(join(directory,'manifest.json'))).digest('hex');
      if(digest!==pointer.manifestSha256) throw new Error('manifest 摘要与登记指针不匹配');
      // Import only our own verifier above, never execute the candidate's VERIFY.mjs.
      const verification=verifyDelivery(directory);
      if(verification.version!==pointer.version) throw new Error('指针版本与交付版本不一致');
      const manifest=read(join(directory,'manifest.json'));
      const all=manifest.packages.map(pkg=>({name:pkg.name,path:join(directory,pkg.file)}));
      // 只列出这个项目需要的包：网页项目不会拿到 Electron 的 tgz
      const packages=all.filter(pkg=>profile.packages.includes(pkg.name));
      const missing=profile.packages.filter(name=>!all.some(pkg=>pkg.name===name));
      if(missing.length) throw new Error('这份交付缺少 '+missing.join('、')+'，不适用于'+(profile.kind==='electron'?' Electron ':'网页')+'项目');
      candidates.push({id:source.id,kind:'delivery',version:verification.version,directory,entry:join(directory,'ai/START_HERE.md'),query:join(directory,'ai/query.mjs'),doctor:join(directory,'ai/doctor.mjs'),packages,manifestSha256:digest,verification,requiresInstall:true});
    } catch(error) { failures.push({id:source.id,message:error.message}); }
  }
  if(sourceId && !config.sources.some(item=>item.id===sourceId)) failures.push({id:sourceId,message:'未登记这个来源'});
  if(candidates.length===1)return result('ready',candidates[0],candidates);
  if(candidates.length>1){warnings.push('存在多个有效来源，请用 --source 指定 id；不会猜测升级目标。');return result('choose-source',null,candidates);}
  return result(failures.length?'needs-attention':'not-found');
}

if(import.meta.url.startsWith('file:') && process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try {
    const args=process.argv.slice(2),options={};
    for(let i=0;i<args.length;i+=2) {
      if(!['--project','--sources','--source'].includes(args[i]) || !args[i+1]) throw new Error('用法：node discover.mjs [--project 目录] [--sources 配置文件] [--source 来源id]');
      options[args[i]==='--source'?'sourceId':args[i].slice(2)]=args[i+1];
    }
    const report=discoverKit(options);console.log(JSON.stringify(report,null,2));
    if(report.status!=='ready')process.exitCode=report.status==='choose-source'?2:1;
  } catch(error){console.error(error.message);process.exitCode=2;}
}
