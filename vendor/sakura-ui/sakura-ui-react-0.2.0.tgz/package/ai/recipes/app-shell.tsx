'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  FloatingPanel, PageTransition, SakuraProvider, SelectField, SidebarNav, SwitchField,
  themePresets, type MotionPreset, type SakuraPalette, type SakuraTheme, type SidebarNavItem,
} from '@sakura-ui/react';
import './recipes.css';

export interface AppShellRecipeProps {
  title: string;
  pageTitle: string;
  items: readonly SidebarNavItem[];
  activeId: string;
  /** Let the host router own URLs, history and authorization. */
  onNavigate: (id: string) => void;
  theme: SakuraTheme;
  onThemeChange: (theme: SakuraTheme) => void;
  palette: SakuraPalette;
  onPaletteChange: (palette: SakuraPalette) => void;
  palettes?: readonly SakuraPalette[];
  motionPreset?: MotionPreset;
  actions?: ReactNode;
  /** Keep navigation quiet and move appearance controls into a popover. */
  compactChrome?: boolean;
  children: ReactNode;
}

/** Includes SakuraProvider. Put route content inside; add ToastProvider only if needed. */
export function AppShellRecipe({ title, pageTitle, items, activeId, onNavigate, theme, onThemeChange,
  palette, onPaletteChange, palettes = themePresets, motionPreset = 'soft', actions, compactChrome = false, children,
}: AppShellRecipeProps) {
  const [collapsed, setCollapsed] = useState(compactChrome);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const previousRoute = useRef(activeId);
  const availablePalettes = palettes.some(item => item.id === palette.id) ? palettes : [palette, ...palettes];
  useEffect(() => {
    if (previousRoute.current !== activeId) {
      previousRoute.current = activeId;
      headingRef.current?.focus({ preventScroll: true });
    }
  }, [activeId]);

  const appearanceControls = <>
    <SelectField label="配色主题" value={palette.id}
      options={availablePalettes.map(item => ({ value: item.id, label: item.name }))}
      onValueChange={id => { const next = availablePalettes.find(item => item.id === id); if (next) onPaletteChange(next); }} />
    <SwitchField label="深色模式" checked={theme === 'dark'} onCheckedChange={checked => onThemeChange(checked ? 'dark' : 'light')} />
  </>;

  return <SakuraProvider theme={theme} palette={palette} motionPreset={motionPreset}>
    <div className="sk-recipe sk-recipe-shell" data-compact-chrome={compactChrome ? '' : undefined}>
      <div className="sk-recipe-desktop-nav">
        <SidebarNav items={items} activeId={activeId} onNavigate={onNavigate}
          collapsed={collapsed} onCollapsedChange={setCollapsed} header={<strong>{title}</strong>} />
      </div>
      <main className="sk-recipe-main">
        <div className="sk-recipe-mobile-nav">
          <SelectField label={title + '导航'} value={activeId} onValueChange={onNavigate}
            options={items.map(item => ({ value: item.id, label: item.label, icon: item.icon }))} />
        </div>
        <header className="sk-recipe-header">
          <div className="sk-recipe-heading">
            {compactChrome && <span className="sk-recipe-brand">{title}</span>}
            <h1 ref={headingRef} tabIndex={-1}>{pageTitle}</h1>
          </div>
          <div className="sk-recipe-toolbar">
            {compactChrome ? <FloatingPanel label="外观设置" title="外观" icon={
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
                <circle cx="12" cy="12" r="8" />
                <path d="M12 4a8 8 0 0 1 0 16Z" fill="currentColor" stroke="none" />
              </svg>
            }><div className="sk-recipe-appearance-controls">{appearanceControls}</div></FloatingPanel> : appearanceControls}
            {actions}
          </div>
        </header>
        <PageTransition routeKey={activeId}>{children}</PageTransition>
      </main>
    </div>
  </SakuraProvider>;
}
