'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Button, DataTable, DrawerPanel, EmptyState, FluidSegmented, PageTransition, StatusBadge, TextField, type StatusTone } from '@sakura-ui/react';
import './recipes.css';

export interface RecipeResource {
  id: string;
  name: string;
  kind: string;
  statusLabel: string;
  statusTone?: StatusTone;
  description?: string;
  /** Optional decorative cover; real thumbnails may instead use renderCover. */
  cover?: 'notes' | 'landscape' | 'ribbon' | 'archive';
}

/**
 * shelf：首件放大陈列，其余放在展架上，适合浏览收藏。
 * index：大字号编号目录，封面跟随当前条目出现，适合按名称查找。
 * list：可排序的表格，适合需要逐行比较的记录。
 * gallery 是 shelf 的旧名称，继续可用。
 */
export type ResourceView = 'shelf' | 'index' | 'list';

export interface ResourceManagerRecipeProps {
  resources: readonly RecipeResource[];
  selectedIds: readonly string[];
  onSelectionChange: (ids: string[]) => void;
  /** Resolve only after the application has accepted/completed its operation. Refresh resources in the host. */
  onBatchAction: (ids: readonly string[]) => Promise<void>;
  batchActionLabel?: string;
  loading?: boolean;
  createAction?: ReactNode;
  initialView?: ResourceView | 'gallery';
  /** 视图切换里提供哪些视图；默认三种都有。只给一种时不显示切换。 */
  views?: readonly ResourceView[];
  title?: string;
  description?: string;
  renderCover?: (resource: RecipeResource) => ReactNode;
  renderDetails?: (resource: RecipeResource) => ReactNode;
}

const viewLabels: Record<ResourceView, string> = { shelf: '陈列', index: '目录', list: '列表' };
const pageSize = 8;

/** Needs an ancestor SakuraProvider. Selection and resources remain owned by the application. */
export function ResourceManagerRecipe({ resources, selectedIds, onSelectionChange, onBatchAction,
  batchActionLabel = '处理所选资源', loading = false, createAction, renderDetails, renderCover,
  initialView = 'list', views = ['shelf', 'index', 'list'], title = '资源', description,
}: ResourceManagerRecipeProps) {
  const startView: ResourceView = initialView === 'gallery' ? 'shelf' : initialView;
  const [query, setQuery] = useState('');
  const [view, setView] = useState<ResourceView>(views.includes(startView) ? startView : views[0]);
  const [visibleCount, setVisibleCount] = useState(pageSize);
  const [announcement, setAnnouncement] = useState('');
  const collectionRef = useRef<HTMLDivElement>(null);
  const nextFocus = useRef<number | null>(null);
  useEffect(() => {
    if (nextFocus.current === null) return;
    // 每件收藏恰好有一个详情触发器，按顺序取第 N 个就是新显示的第一件
    collectionRef.current?.querySelectorAll<HTMLElement>('button[aria-label^="查看 "]').item(nextFocus.current)?.focus();
    nextFocus.current = null;
  }, [visibleCount]);
  function changeQuery(value: string) { setQuery(value); setVisibleCount(pageSize); setAnnouncement(''); }
  const matches = resources.filter(row => `${row.name} ${row.kind} ${row.statusLabel}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  const [pending, setPending] = useState(false);
  const [feedback, setFeedback] = useState<{ error: boolean; text: string } | null>(null);
  const pendingRef = useRef(false);
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  const existingIds = new Set(resources.map(resource => resource.id));
  const validSelection = [...new Set(selectedIds)].filter(id => existingIds.has(id));

  async function runBatch() {
    if (pendingRef.current || loading || !validSelection.length) return;
    const ids = [...validSelection];
    pendingRef.current = true; setPending(true); setFeedback(null);
    try {
      await onBatchAction(ids);
      if (mounted.current) setFeedback({ error: false, text: `已处理 ${ids.length} 项资源。` });
    } catch (error) {
      if (mounted.current) setFeedback({ error: true, text: error instanceof Error ? error.message : '处理失败，请重试。' });
    } finally {
      pendingRef.current = false;
      if (mounted.current) setPending(false);
    }
  }

  function cover(row: RecipeResource) {
    return renderCover ? <span className="sk-collection-custom-cover">{renderCover(row)}</span> : <ResourceCover resource={row} />;
  }
  function detailBody(row: RecipeResource) {
    return <div className="sk-recipe sk-recipe-details">
      {renderDetails ? renderDetails(row) : <>
        <div className="sk-collection-detail-cover">{cover(row)}</div>
        <StatusBadge tone={row.statusTone}>{row.statusLabel}</StatusBadge>
        <dl><dt>类型</dt><dd>{row.kind}</dd><dt>说明</dt><dd>{row.description || '暂无说明'}</dd></dl>
      </>}
    </div>;
  }
  function opener(row: RecipeResource, className: string, content: ReactNode) {
    return <DrawerPanel triggerLabel={'查看 ' + row.name} triggerContent={content} title={row.name} description="资源详情" triggerClassName={className}>
      {detailBody(row)}
    </DrawerPanel>;
  }
  function selector(row: RecipeResource) {
    const checked = validSelection.includes(row.id);
    return <label className="sk-collection-select">
      <input type="checkbox" aria-label={'选择 ' + row.name} checked={checked} disabled={pending || loading}
        onChange={event => onSelectionChange(event.target.checked ? [...validSelection, row.id] : validSelection.filter(id => id !== row.id))} />
      <span aria-hidden="true">✓</span>
    </label>;
  }

  const shown = matches.slice(0, visibleCount);
  const batch = <Button size="sm" disabled={loading || pending || !validSelection.length} onClick={() => void runBatch()}>{pending ? '正在处理…' : batchActionLabel}</Button>;
  const more = matches.length > visibleCount && <Button variant="ghost" className="sk-collection-more" onClick={() => {
    nextFocus.current = visibleCount;
    setAnnouncement(`已显示另外 ${Math.min(pageSize, matches.length - visibleCount)} 份收藏`);
    setVisibleCount(count => count + pageSize);
  }}>显示更多收藏</Button>;

  return <section className="sk-recipe sk-recipe-resources" data-view={view} data-presentation={startView === 'list' ? 'list' : 'collection'} aria-label="资源管理" aria-busy={loading || pending}>
    <div className="sk-collection-heading"><div><h2>{title}</h2>{description && <p>{description}</p>}</div>{createAction}</div>
    <div className="sk-collection-viewbar">
      <span className="sk-collection-count">{resources.length} 份收藏{validSelection.length > 0 && `，已选 ${validSelection.length} 项`}</span>
      {views.length > 1 && <FluidSegmented label="资源视图" value={view} onValueChange={value => setView(value as ResourceView)}
        options={views.map(value => ({ value, label: viewLabels[value] }))} />}
    </div>
    {feedback && <p className="sk-recipe-feedback" data-error={feedback.error || undefined} role={feedback.error ? 'alert' : 'status'}>{feedback.text}</p>}
    <PageTransition routeKey={view}>{!loading && resources.length === 0
      ? <EmptyState title="还没有资源" description="添加后可以搜索、选择和查看详情。" />
      : view !== 'list' ? <>
        <div className="sk-collection-tools"><TextField label="搜索资源" type="search" placeholder="寻找名称、类型或状态" value={query} onChange={event => changeQuery(event.target.value)} />{batch}</div>
        {loading ? <p role="status">正在加载资源…</p> : matches.length === 0 ? <EmptyState title="没有找到匹配的收藏" description="试试其他名称，或清空搜索。" /> : <>
          <div ref={collectionRef}>
            {view === 'shelf'
              ? <ShelfView items={shown} selected={validSelection} opener={opener} cover={cover} selector={selector} />
              : <IndexView items={shown} selected={validSelection} opener={opener} cover={cover} selector={selector} />}
          </div>
          {more}
        </>}
        <span className="sk-collection-sr" role="status">{announcement}</span>
      </> : <DataTable label="资源列表" rows={resources} getRowId={row => row.id} getRowLabel={row => row.name}
          columns={[
            { id: 'name', header: '名称', cell: row => row.name, sortValue: row => row.name },
            { id: 'kind', header: '类型', cell: row => row.kind, sortValue: row => row.kind },
            { id: 'status', header: '状态', cell: row => <StatusBadge tone={row.statusTone}>{row.statusLabel}</StatusBadge> },
          ]}
          query={query} onQueryChange={changeQuery} searchText={row => `${row.name} ${row.kind} ${row.statusLabel}`}
          selectedIds={validSelection} onSelectionChange={onSelectionChange} loading={loading || pending} pageSize={pageSize}
          toolbar={batch} rowActions={row => opener(row, 'sk-button', '详情')} />}</PageTransition>
  </section>;
}

interface CollectionViewProps {
  items: readonly RecipeResource[];
  selected: readonly string[];
  opener: (row: RecipeResource, className: string, content: ReactNode) => ReactNode;
  cover: (row: RecipeResource) => ReactNode;
  selector: (row: RecipeResource) => ReactNode;
}

/** 首件放大陈列，其余按行排在展架上；任意数量都按同一规则排布。 */
function ShelfView({ items, selected, opener, cover, selector }: CollectionViewProps) {
  const [featured, ...rest] = items;
  if (!featured) return null;
  return <div className="sk-shelf">
    <article className="sk-shelf-feature" data-selected={selected.includes(featured.id) || undefined}>
      {opener(featured, 'sk-shelf-feature-open', cover(featured))}
      <div className="sk-shelf-feature-copy">
        <span className="sk-shelf-label">{featured.kind}</span>
        <h3>{featured.name}</h3>
        {featured.description && <p>{featured.description}</p>}
        <div className="sk-shelf-feature-meta"><StatusBadge tone={featured.statusTone}>{featured.statusLabel}</StatusBadge>{selector(featured)}</div>
      </div>
    </article>
    {rest.length > 0 && <>
      <div className="sk-shelf-rule"><span>其余 {rest.length} 件</span></div>
      <ul className="sk-shelf-row" aria-label="资源收藏">
        {rest.map(row => <li key={row.id} data-selected={selected.includes(row.id) || undefined}>
          {opener(row, 'sk-shelf-open', cover(row))}
          <div className="sk-shelf-caption">
            <div><span className="sk-shelf-kind">{row.kind}</span><h3>{row.name}</h3></div>
            {selector(row)}
          </div>
          <div className="sk-shelf-status"><StatusBadge tone={row.statusTone}>{row.statusLabel}</StatusBadge></div>
        </li>)}
      </ul>
    </>}
  </div>;
}

/** 编号目录：悬停或聚焦的条目在右侧显示封面；窄屏隐藏预览。 */
function IndexView({ items, selected, opener, cover, selector }: CollectionViewProps) {
  const [activeId, setActiveId] = useState(items[0]?.id);
  const active = items.find(row => row.id === activeId) ?? items[0];
  if (!active) return null;
  return <div className="sk-index">
    <ol className="sk-index-list" aria-label="资源收藏">
      {items.map((row, number) => <li key={row.id} data-active={row.id === active.id || undefined} data-selected={selected.includes(row.id) || undefined}
        onMouseEnter={() => setActiveId(row.id)} onFocus={() => setActiveId(row.id)}>
        {opener(row, 'sk-index-open', <>
          <span className="sk-index-number">{String(number + 1).padStart(2, '0')}</span>
          <span className="sk-index-name">{row.name}</span>
          <span className="sk-index-kind">{row.kind}</span>
        </>)}
        {selector(row)}
      </li>)}
    </ol>
    <aside className="sk-index-preview" aria-hidden="true">
      <div className="sk-index-preview-cover" key={active.id}>{cover(active)}</div>
      <div className="sk-index-preview-meta"><StatusBadge tone={active.statusTone}>{active.statusLabel}</StatusBadge>{active.description && <p>{active.description}</p>}</div>
    </aside>
  </div>;
}

/** Decorative, theme-aware fallback artwork. Supply renderCover for real asset previews. */
export function ResourceCover({resource}:{resource:RecipeResource}) {
  return <span className="sk-collection-art" data-cover={resource.cover || 'archive'} aria-hidden="true">
    <span className="sk-collection-object">
      <span className="sk-collection-layer sk-collection-layer-back" />
      <span className="sk-collection-layer sk-collection-layer-middle" />
      <span className="sk-collection-layer sk-collection-layer-front"><span className="sk-collection-object-label">{resource.kind}</span></span>
    </span>
  </span>;
}
