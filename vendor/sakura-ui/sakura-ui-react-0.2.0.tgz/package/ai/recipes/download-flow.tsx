'use client';

import { useState } from 'react';
import {
  DownloadPanel, FocusDialog, StatusBadge, useDownloadTask,
  type DownloadExecutor, type DownloadResource, type DownloadTarget, type DownloadTaskController, type DownloadTaskState,
} from '@sakura-ui/react';
import './recipes.css';

export interface DownloadFlowRecipeProps {
  resource: DownloadResource;
  targets: readonly DownloadTarget[];
  execute: DownloadExecutor;
  /** Lift useDownloadTask above this recipe as well if the route can unmount it. */
  controller?: DownloadTaskController;
  initialTargetId?: string;
}

function taskLabel(state: DownloadTaskState): string {
  if (state.status === 'idle') return '尚未开始';
  if (state.status === 'running') return '下载进行中';
  if (state.status === 'cancelling') return '等待取消确认';
  if (state.status === 'error') return '下载失败';
  const labels = { completed: '文件已保存', submitted: '任务已提交', 'handed-off': '已交给浏览器', cancelled: '已确认取消', interrupted: '保存状态未确认' };
  return state.result.simulated ? '演示结果，请查看详情' : labels[state.result.kind];
}

/** Needs SakuraProvider. Closing the dialog keeps the controller mounted; it does not cancel a task. */
export function DownloadFlowRecipe({ resource, targets, execute, controller, initialTargetId }: DownloadFlowRecipeProps) {
  const localController = useDownloadTask(execute);
  const task = controller ?? localController;
  const [open, setOpen] = useState(false);
  const { state } = task;
  const succeeded = state.status === 'terminal' && state.result.kind === 'completed' && !state.result.simulated;
  return <section className="sk-recipe sk-recipe-download" aria-label="下载">
    <div className="sk-recipe-header">
      <div><h2>{resource.label}</h2><p>{resource.fileName}</p></div>
      <span role="status"><StatusBadge tone={state.status === 'error' ? 'danger' : succeeded ? 'success' : 'neutral'}>{taskLabel(state)}</StatusBadge></span>
    </div>
    <FocusDialog triggerLabel={state.status === 'idle' ? '配置下载' : '查看下载'} title="下载文件"
      description="选择保存目标并确认参数。关闭面板后，当前页面仍会保留下载进度。"
      open={open} onOpenChange={setOpen}>
      <DownloadPanel resource={resource} targets={targets} execute={execute} controller={task} initialTargetId={initialTargetId} />
    </FocusDialog>
  </section>;
}
