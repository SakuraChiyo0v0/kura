export interface ApiSnapshot {
  schemaVersion:1;normalizerVersion:1;package:string;version:string;surfaceHash:string;
  dependencies:Record<string,string>;peerDependencies:Record<string,string>;
  entries:{id:string;category:'components'|'types'|'apis';name:string;kind:string;tokens:string[];definition:string;props?:{name:string;required:boolean;type:string;tokens:string[]}[]}[];
}
export function surfaceFingerprint(snapshot:Omit<ApiSnapshot,'surfaceHash'>|ApiSnapshot):string;
export function compareSnapshots(before:ApiSnapshot,after:ApiSnapshot):{status:string;compatibility:string;changes:{level:string;kind:string;name:string;detail:unknown}[]};
