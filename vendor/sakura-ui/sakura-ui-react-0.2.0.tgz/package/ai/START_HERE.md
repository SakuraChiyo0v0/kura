# 用 Sakura UI 构建项目

先读本页；按任务查询组件，再读相关范例。不要一次载入整个源码或所有契约。

若新项目还没有组件包，可先使用已安装个人 Skill 中的 `scripts/discover.mjs --project "项目目录"` 发现本机登记的交付材料。来源配置只属于本机，不随包分发，详见 [交付发现](skill/references/discovery.md)。发现材料不等于已经安装或获准升级。

## 先确认环境

安装前可用交付目录中的诊断器，安装后也可复查：

```sh
node ai/doctor.mjs --project "你的项目目录"
# 在已安装组件的项目中：
node node_modules/@sakura-ui/react/ai/doctor.mjs
```

诊断只读文件，不安装、不升级、不执行项目脚本。返回 JSON：`needs-attention`（退出码 1）说明依赖有缺失或冲突；`dependencies-ready`（退出码 0）只说明当前依赖检查通过。报告分别列出项目声明与实际解析位置，不完整解释复杂 semver 或锁文件，也不证明 Provider/CSS 已正确初始化、SSR 兼容或页面可用。

- 当前包：`@sakura-ui/react` 0.1.0，React / React DOM 19，另需同版本 `@sakura-ui/tokens`。实验期 API 可能变化，以安装包中的 catalog.json 和类型为准。
- 包尚未发布到注册表。取得维护者提供的两个 `.tgz` 后，在目标项目用 `npm install <tokens-tgz路径> <react-tgz路径>` 安装；不要把开发机的绝对路径写进可移植项目。
- 已有 React 18 或其他框架时先评估兼容，不静默升级整个项目。当前范例按 React + TypeScript 客户端应用验证，未承诺 SSR、Next.js 或 Vue 支持。
- 独立项目导入公共包，不引用 `packages/ui/src` 或 `apps/lab`。范例可复制并修改，组件内部逻辑通过安装包复用。

## 定位和查询

在消费项目运行以下命令，可定位真实安装位置（不加载 React）：

```sh
node -p "require.resolve('@sakura-ui/react/ai/START_HERE.md')"
node -p "require.resolve('@sakura-ui/react/ai/query.mjs')"
```

将第二条输出的文件路径传给 Node，按需执行 `search 下载`、`show DownloadPanel`、`recipes` 或 `list`。常规 node_modules 布局可以直接运行：

```sh
node node_modules/@sakura-ui/react/ai/query.mjs search 下载
node node_modules/@sakura-ui/react/ai/query.mjs show DownloadPanel
node node_modules/@sakura-ui/react/ai/query.mjs show DownloadTarget
node node_modules/@sakura-ui/react/ai/query.mjs show useDownloadTask
node node_modules/@sakura-ui/react/ai/query.mjs search 收藏
node node_modules/@sakura-ui/react/ai/query.mjs recipes
```

搜索结果中的 `matches` 是组件，`recipes` 是组合范例，`types` 是公共类型，`apis` 是 Hook/函数/Provider 等基础接口；例如“资源”或“收藏”会找到资源管理范例，“主题”可以找到 SakuraProvider。`types` 和 `apis` 命令只列对应索引。不使用 Node 时，可以直接读取 [catalog.json](catalog.json)，再按 `contract` 路径打开单个文件。查询脚本不安装依赖、不连接服务、不执行用户操作。

契约中的 `props` 来自实际公共类型，标注必填项、类型与注释。`relatedTypes` 提供进一步查询入口，例如 `useDownloadTask → DownloadExecutor → DownloadRequest / DownloadResult`；用 `show` 查询每个名称。类型定义保留泛型和联合分支，函数只给真实签名而不输出实现。

这些定义是接口说明，不是完整独立源码或 JSON Schema。React、Motion 等外部类型及必要的完整声明仍可查 `../dist/index.d.ts` 和相邻文件，不要把字符串定义用于运行时输入校验。JSON 中的关联链接只指向本库公开类型；基础函数签名中的公开类型名用于建立索引，不代表完整依赖图。

## 初始化一次

```tsx
import '@sakura-ui/tokens/tokens.css';
import '@sakura-ui/react/styles.css';
import { SakuraProvider, themePresets } from '@sakura-ui/react';

export function App() {
  return <SakuraProvider theme="light" motionPreset="soft" palette={themePresets[0]}>
    <main>项目内容</main>
  </SakuraProvider>;
}
```

需要 `useToast` 时，在 SakuraProvider 内增加 ToastProvider。亮暗、颜色、请求、路由和持久化由宿主管理。使用 AppShellRecipe 时，它已经提供 SakuraProvider，不再重复包装。

自写样式只引用 tokens.css 提供的变量：表面层级 `--sk-surface-sunken / bg / surface / surface-raised / surface-overlay`，实心填充 `--sk-<role>-solid` 配 `--sk-on-<role>-solid`，时长 `--sk-fast / --sk-settle`。完整清单见 `@sakura-ui/tokens` 包内 README；选用规则见 design-rules.md。非 React 项目要沿用同一地基时，可读取包内 `foundation.json`（前缀无关的变量清单）在构建期生成自己的变量。

## Electron 产品

桌面应用另装 `@sakura-ui/electron`（`/main` 主进程、`/preload` 桥、`/shared` 两侧契约）与 `@sakura-ui/electron-react`（标题栏、窗口按钮、设置页版式、更新提示条与 Hook）。系统能力按「主进程注册 → preload 暴露 → 渲染层 Hook」三段接入，渲染层拿不到系统 API。设置页里的开关、下拉、输入用本库的 `SwitchField` / `SelectField` / `TextField`，不要另写控件。样式依次引入 tokens、`@sakura-ui/react/styles.css`、`@sakura-ui/electron-react/styles.css`。用同一个查询器 `node .../query.mjs electron` 列出桌面包的组件、Hook 与主进程 / preload API，`show <名称>` 读契约（含 `importFrom` 与 `runsIn` 运行进程）；`search` 的桌面结果单独放在 `electron` 字段。接入写法见这两个包的 README。网页项目不要安装它们。

交付目录同时带四个 tgz：网页项目装 tokens 与 react 两个，Electron 项目四个都装（READ_FIRST.md 给出两条安装命令）。`discover.mjs` 会按项目是否依赖 `electron` 只列出需要的包。Electron 本身由项目自行安装；只用 tsc、不用 Vite 的主进程工程需自己声明 `declare module '*.css'`。

## 按需求选择材料

| 需求 | 先读 |
| --- | --- |
| 选择交互、控制信息密度、延续设计风格 | [design-rules.md](design-rules.md) |
| 应用侧栏、紧凑布局、页面切换、外观浮窗 | [app-shell.tsx](recipes/app-shell.tsx) |
| 收藏浏览、可替换封面、搜索列表、批量操作和详情抽屉 | [resource-manager.tsx](recipes/resource-manager.tsx) |
| 本机/服务端/WebDAV 下载 | [download-flow.tsx](recipes/download-flow.tsx) |
| 三份范例的 props 与最小接入 | [范例说明](recipes/README.md) |
| 具体属性与基础 hooks | [组件 README](../README.md)、相应 `components/*.json` 和 `../dist/*.d.ts` |
| 把此流程装成个人 Skill | [skill/SKILL.md](skill/SKILL.md)，复制整个 skill 文件夹并命名为 sakura-ui |

范例索引的 `distribution: copy-template` 表示需要复制的应用模板，并非组件包新增导出；`useWhen` 和 `boundary` 帮助选型，实际属性以 TSX 和范例说明为准。收藏浏览用 `initialView="shelf"`（陈列）或 `"index"`（目录），`views` 限定可切换的视图；图片封面用 `renderCover`；紧凑外壳用 `compactChrome`，不要把这些名称误当作基础组件属性。

复制选中的 `.tsx` 和同目录 `recipes.css` 到消费项目，再填入本项目的状态和回调。保留 `'use client'` 不表示已经验证所有 SSR 框架。

下载范例不提供模拟执行器。真实执行器返回保存完成、任务入队或交给浏览器的不同结果；只在确有证据时报告相应状态。服务端/WebDAV 凭据与真实文件路径留在后端，前端传目标标识和相对目录。不要复制 Studio 演示后宣称已完成远端文件保存。

## 完成接入后

升级前可以比较两份交付中的 `ai/api-snapshot.json`：

```sh
node ai/api-diff.mjs --before "旧交付/ai/api-snapshot.json" --after "新交付/ai/api-snapshot.json"
```

报告区分新增、移除/必填变化的风险和需要审查的类型变化。加 `--check` 时任何差异返回退出码 1；格式损坏返回 2。`unchanged` 只说明捕获的声明未变，不证明运行时、外部类型、样式或视觉兼容。旧交付没有快照时，不能补造历史兼容结论，应直接检查实际使用点并运行消费项目验证。

先在消费项目执行类型检查与构建，再验证相关交互：打开/返回、空态/错误、异步等待、键盘、亮暗主题和窄屏。对涉及状态保存的流程，验证重试、关闭和重新进入。是否完成真实业务要以回调/服务回执判断。

汇报时区分“能编译”“行为测试通过”“浏览器实测”“用户认可”。没有浏览器权限就记录限制，不用测试数字宣称视觉验收。
