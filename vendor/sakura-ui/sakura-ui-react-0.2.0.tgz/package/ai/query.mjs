import { readFileSync } from 'node:fs';
const read = relative => JSON.parse(readFileSync(new URL(relative, import.meta.url),'utf8'));
const catalog = read('./catalog.json');
const electron = catalog.electron || {components:[],typeIndex:[],apis:[]};
const [command='help',...args] = process.argv.slice(2);
const summary = item => ({name:item.name,kind:item.kind,importFrom:item.importFrom,runsIn:item.runsIn,useWhen:item.useWhen,description:item.description,contract:item.contract,examples:item.examples,relatedTypes:item.relatedTypes});
const matching = (items,terms) => items.filter(item=>terms.every(term=>JSON.stringify(item).toLowerCase().includes(term)));
try {
  if(command==='list') console.log(JSON.stringify({version:catalog.version,components:catalog.components.map(summary)},null,2));
  else if(command==='recipes') console.log(JSON.stringify(catalog.recipes,null,2));
  else if(command==='types') console.log(JSON.stringify((catalog.typeIndex||[]).map(summary),null,2));
  else if(command==='apis') console.log(JSON.stringify((catalog.apis||[]).map(summary),null,2));
  else if(command==='electron') console.log(JSON.stringify({note:electron.note,packages:electron.packages,readme:electron.readme,components:electron.components.map(summary),apis:electron.apis.map(summary),types:electron.typeIndex.map(item=>item.name)},null,2));
  else if(command==='search') {
    if(!args.join(' ').trim()) throw new Error('请输入关键词，例如 search 下载');
    const terms=args.join(' ').toLowerCase().split(/\s+/).filter(Boolean);
    const result={
      matches:matching(catalog.components,terms).map(summary),
      recipes:matching(catalog.recipes,terms),
      types:matching(catalog.typeIndex||[],terms).map(summary),
      apis:matching(catalog.apis||[],terms).map(summary),
    };
    // Electron 结果单列，避免网页项目误装桌面包
    const desktop={components:matching(electron.components,terms).map(summary),types:matching(electron.typeIndex,terms).map(summary),apis:matching(electron.apis,terms).map(summary)};
    if(desktop.components.length || desktop.types.length || desktop.apis.length) result.electron={note:electron.note,...desktop};
    console.log(JSON.stringify(result,null,2));
  } else if(command==='show') {
    const wanted=args.join(' ').toLowerCase();
    const item=[...catalog.components,...(catalog.typeIndex||[]),...(catalog.apis||[]),...electron.components,...electron.typeIndex,...electron.apis].find(item=>item.name.toLowerCase()===wanted);
    if(!item) throw new Error('未知公共接口，请先使用 search、list、types、apis 或 electron。');
    // File path comes from the packaged allowlist, never from CLI input.
    console.log(JSON.stringify(read('./'+item.contract),null,2));
  } else if(command==='help') console.log('Sakura UI '+catalog.version+'\nlist | types | apis | electron | search <关键词> | show <公共名称> | recipes\nshow 可查询组件、公开类型、Hook、函数和 Provider；electron 列出桌面应用专用的包与接口。先读同目录 START_HERE.md；只读取数据，不安装、不执行业务。');
  else throw new Error('未知命令：'+command);
} catch(error) { console.error(error.message);process.exitCode=1; }
