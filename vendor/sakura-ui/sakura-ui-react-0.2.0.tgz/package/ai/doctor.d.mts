export interface Diagnosis {
  schemaVersion: 1;
  project: string;
  status: 'needs-attention' | 'dependencies-ready';
  packages: {name:string;declarations:{section:string;value:unknown}[];installedVersion:string|null;resolvedManifest:string|null}[];
  checks: {code:string;severity:'error'|'warning'|'info';message:string}[];
  notVerified: string[];
}
export function diagnoseProject(projectDirectory: string): Diagnosis;
